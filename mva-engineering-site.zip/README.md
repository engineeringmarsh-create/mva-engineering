# Engineering with Mr. Marsh

Interactive, self-paced engineering courses for Mr. Marsh's classes at Montverde Academy. The site is plain HTML, CSS and JavaScript with no build step, so it runs on GitHub Pages as-is.

| Course | Code | Level | Weeks | Lessons |
|---|---|---|---|---|
| Elements of Engineering | EE | Introductory | 18 | 90 |
| Basic Engineering | BE | Survey | 18 | 90 |
| Advanced Engineering | AE | Capstone | 18 | 90 |

## Publish on GitHub Pages

1. Push these files to the `main` branch of the repository.
2. On GitHub, open **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to *Deploy from a branch*, pick **main** and **/ (root)**, then click **Save**.
4. After a minute or two, the site is live at `https://engineeringmarsh-create.github.io/mva-engineering/`.

## Preview on your computer

Open `index.html` in a browser by double-clicking it. Everything works offline except the Google Fonts.

## Folder structure

```
index.html            Homepage
courses.html          All courses
course.html           Course overview        (course.html?course=basic)
week.html             Weekly module          (week.html?course=basic&week=4)
lesson.html           Lesson template        (lesson.html?course=basic&week=4&day=3)
resources.html        Resource library and reference sheets
gallery.html          Project gallery
progress.html         Student progress tracker
pathway.html          Engineering pathway graphic
about.html            About the program
contact.html          Contact page
404.html              Not-found page

assets/css/main.css   All site styles
assets/js/site.js     Shared header/footer, data loading, progress tracking, completion codes
assets/js/pages.js    Course, week, course-list and progress page rendering
assets/js/lesson.js   Lesson page rendering (the seven-section lesson template)
assets/img/           Favicon and images

data/catalog.js       The list of courses
data/<course>/course.js     Course map: units, 18 weeks, 90 lesson titles
data/<course>/week-XX.js    Full lesson content for one week

templates/week-template.js    Copy this to write a new week
templates/course-template.js  Copy this to add a new course
```

## How lessons work

Every lesson renders from data into the same seven sections:

1. Learning objectives
2. Reading and instruction (with vocabulary and an ungraded quick check)
3. Guided walkthrough
4. Worked example (solution hidden until revealed)
5. Activity or project work (checklist saved on the student's device)
6. Reflection questions (answers saved on the device)
7. Completion screen

The completion screen unlocks after the student opens sections 1–6 and answers every reflection question. It shows a verification code like `BE-W04-D03-5837`: course code, week, day and four random digits. The digits are regenerated every time the page loads, so an old screenshot won't match a new attempt. The screen also shows when the code was generated.

Students paste the code into the matching Canvas assignment.

> **Note:** The code proves a student reached the end of the lesson. It can't be checked automatically against a list, because any four digits are valid. Use it as a completion signal together with the reflection answers and activity deliverables.

## Writing new lessons

1. Copy `templates/week-template.js` to `data/<course>/week-XX.js` (for example `data/basic/week-02.js`).
2. Change `MVA.registerWeek("basic", 4, …)` to the right course and week.
3. Fill in the five lessons. Titles come from `course.js`, so you only write the content.
4. Open `data/<course>/course.js` and add the week number to `publishedWeeks`, e.g. `publishedWeeks: [1, 2]`.

Lessons in weeks that aren't listed in `publishedWeeks` show as **In development** and don't give a completion code.

To rename a lesson or change the course map, edit `data/<course>/course.js`.

## Adding a course in a future year

1. Copy `templates/course-template.js` to `data/<new-id>/course.js` and fill it in.
2. Add one line to `data/catalog.js`.
3. Optionally add a course color in `assets/css/main.css`.

## Settings to update

- **Contact form email:** in `assets/js/site.js`, set `email: ""` to your school email to turn on the contact form. Until then, it tells students to use the Canvas Inbox.
- **About page bio:** replace the bracketed placeholder paragraph in `about.html`.

## Current status

- Site framework, all pages and the full 270-lesson course map: done
- Fully written lessons: Week 1 of each course (15 lessons)
- Weeks 2–18: titles and focus lines in place, content in development
