/* ==========================================================================
   COURSE TEMPLATE: copy this to add a new course (e.g. Robotics).

   1. Create a folder:   data/<course-id>/
   2. Copy this file to: data/<course-id>/course.js
   3. Add the course to data/catalog.js:
        { id: "robotics", code: "RE", title: "Robotics Engineering", folder: "data/robotics" }
   4. Optional: add a color for it in assets/css/main.css
        body[data-course="robotics"] { --course: #6a3fb5; --course-soft: #efe9f8; }
   ========================================================================== */
MVA.registerCourse({
  id: "robotics",          // lowercase, no spaces; used in URLs
  code: "RE",              // 2–3 letters; first part of the completion code (RE-W01-D01-1234)
  title: "Robotics Engineering",
  level: "Elective",
  audience: "Basic Engineering recommended",
  tagline: "One sentence for the course card.",
  description: "Two or three sentences for the course page.",
  disciplines: ["Mechanical", "Electrical", "Software"],
  tools: ["Onshape", "VEX or REV kits"],
  outcomes: [
    "What students will be able to do by the end",
    "..."
  ],
  publishedWeeks: [],      // add week numbers as you finish week-XX.js files
  units: [
    { title: "Unit 1 name", weeks: [1, 2, 3] }
    // ...
  ],
  weeks: [
    // One entry per week. Each lesson is [title, one-line focus].
    { title: "Week 1 title", summary: "One-line summary of the week.",
      lessons: [
        ["Day 1 title", "Day 1 focus."],
        ["Day 2 title", "Day 2 focus."],
        ["Day 3 title", "Day 3 focus."],
        ["Day 4 title", "Day 4 focus."],
        ["Day 5 title", "Day 5 focus."]
      ] }
    // ... repeat for every week
  ]
});
