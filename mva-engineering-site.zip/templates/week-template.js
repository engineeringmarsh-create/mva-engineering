/* ==========================================================================
   WEEK TEMPLATE: copy this file to write a new week of lessons.

   1. Copy to:  data/<course>/week-XX.js   (e.g. data/basic/week-04.js)
   2. Change the course id and week number in MVA.registerWeek below.
   3. Fill in the five lessons. Lesson titles and focus lines come from
      data/<course>/course.js, so you don't repeat them here.
   4. Add the week number to publishedWeeks in data/<course>/course.js.
      Until you do, the lessons show as "In development" and give no code.

   Text fields accept HTML: <p>, <b>, <i>, <ul>, <ol>, <li>, <h3>, <a>, <img>.
   Use backticks (`...`) for long multi-line text.
   Fields marked optional can be deleted.
   ========================================================================== */
MVA.registerWeek("basic", 4, {

  1: {
    duration: "45 min",                                   // optional

    // 1. LEARNING OBJECTIVES: start each with a measurable verb
    objectives: [
      "Objective one",
      "Objective two",
      "Objective three"
    ],
    before: "<p>Materials or setup students need first.</p>",   // optional

    // 2. READING AND INSTRUCTION
    reading: `
      <h3>Section heading</h3>
      <p>Explain the core idea in plain language.</p>
      <h3>Another section</h3>
      <p>Keep paragraphs short. Use examples students recognize.</p>
    `,
    vocab: [                                              // optional
      ["Term", "Definition."],
      ["Term", "Definition."]
    ],
    check: [                                              // optional, ungraded quiz
      { q: "Question?",
        options: ["Choice A", "Choice B", "Choice C"],
        answer: 1,                                        // index of correct option, starting at 0
        explain: "Why the answer is correct." }
    ],

    // 3. GUIDED WALKTHROUGH: steps students do along with the lesson
    walkthrough: {
      intro: "<p>What students will practice and what to have open.</p>",
      steps: [
        { title: "Step title", body: "<p>Exactly what to do.</p>" },
        { title: "Step title", body: "<p>Exactly what to do.</p>" }
      ]
    },

    // 4. WORKED EXAMPLE: solution is hidden until the student reveals it
    example: {
      title: "Example problem title",
      problem: "<p>The full problem statement.</p>",
      steps: [
        "First solution step.",
        "Second solution step."
      ],
      answer: "The final answer.",
      takeaway: "The one thing to remember."            // optional
    },

    // 5. ACTIVITY OR PROJECT WORK
    activity: {
      title: "Activity name",
      time: "25 min",
      tools: ["Tinkercad", "Notebook"],
      deliverable: "What students submit",
      intro: "<p>Context for the activity.</p>",
      steps: [
        "Checklist step one.",
        "Checklist step two."
      ],
      rubric: "<ul><li>Grading criterion</li></ul>",   // optional
      extension: "Challenge for students who finish early."  // optional
    },

    // 6. REFLECTION QUESTIONS: all must be answered to unlock the code
    reflection: [
      "Question one?",
      "Question two?",
      "Question three?"
    ],

    resources: [                                          // optional
      { label: "Link text", url: "https://example.com" }
    ]
    // 7. COMPLETION SCREEN is generated automatically.
  },

  2: { /* same structure as lesson 1 */ },
  3: { /* ... */ },
  4: { /* ... */ },
  5: { /* ... */ }
});
