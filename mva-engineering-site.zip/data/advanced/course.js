/* Advanced Engineering — course map (18 weeks x 5 lessons)
   Capstone course modeled on Engineering Design and Development.
   Each lesson entry is [title, focus]. Full lesson content lives in week-XX.js.
   When you finish writing a week file, add its number to publishedWeeks. */
MVA.registerCourse({
  id: "advanced",
  code: "AE",
  title: "Advanced Engineering",
  level: "Capstone",
  audience: "Basic Engineering recommended",
  tagline: "Find a real problem. Spend a semester engineering the solution.",
  description:
    "A capstone course modeled on Engineering Design and Development. You'll identify a real-world problem and spend the semester developing a solution: problem justification, research, patent searches, market analysis, brainstorming, CAD, prototyping, testing, data analysis and a professional final presentation. Choose a project in robotics, aerospace, manufacturing, renewable energy, AI, transportation, infrastructure, biomedical engineering or any field you can justify.",
  disciplines: ["Robotics", "Aerospace", "Manufacturing", "Renewable energy", "AI", "Transportation", "Infrastructure", "Biomedical"],
  tools: ["Onshape", "Engineering notebook", "Google Patents", "Spreadsheets", "Any tools your project requires"],
  outcomes: [
    "Identify and justify a real problem with evidence from users and data",
    "Conduct research, patent searches and market analysis to define design specifications",
    "Develop, prototype and iterate a solution using CAD and testing",
    "Design tests, collect data and draw conclusions from it",
    "Document your work professionally and defend it in a final presentation"
  ],
  publishedWeeks: [1],
  units: [
    { title: "Launch and problem identification", weeks: [1, 2] },
    { title: "Research, patents and markets", weeks: [3, 4, 5] },
    { title: "Concept design", weeks: [6, 7, 8] },
    { title: "Prototyping", weeks: [9, 10, 11, 12] },
    { title: "Testing and iteration", weeks: [13, 14, 15] },
    { title: "Documentation and presentation", weeks: [16, 17, 18] }
  ],
  weeks: [
    { title: "Capstone launch", summary: "How the capstone works, your notebook, your team and finding problems.",
      lessons: [
        ["Welcome to the capstone", "What a capstone is, the semester roadmap and how you'll be assessed."],
        ["The professional engineering notebook", "Set up a notebook that could stand up in a patent dispute."],
        ["Project management", "Plan a semester with milestones, a Gantt chart and weekly goals."],
        ["Engineering ethics", "Responsibilities engineers carry to the public, clients and each other."],
        ["Problem hunting", "Observe the world and log at least ten real problems."]
      ] },
    { title: "Problem identification", summary: "Find the real problem, the people who have it and the evidence that it matters.",
      lessons: [
        ["Problems versus symptoms", "Find root causes with the five whys and fishbone diagrams."],
        ["Stakeholders and interviews", "Identify who is affected and interview them well."],
        ["Writing a problem statement", "Write a clear, solution-free problem statement."],
        ["Justifying the problem", "Back your problem with data and credible sources."],
        ["Problem approval presentation", "Pitch your problem for approval."]
      ] },
    { title: "Research", summary: "Background research, credible sources and existing solutions.",
      lessons: [
        ["Research strategy", "Plan what you need to know and where to find it."],
        ["Credible sources and citations", "Evaluate sources and cite them in IEEE style."],
        ["Existing solutions", "Find and analyze products that already address your problem."],
        ["Writing a literature review", "Synthesize research into a clear summary."],
        ["Research check-in", "Review your research with the teacher and a peer."]
      ] },
    { title: "Patents and intellectual property", summary: "Protect ideas and avoid reinventing existing ones.",
      lessons: [
        ["Intellectual property basics", "Patents, trademarks, copyrights and trade secrets."],
        ["Searching patents", "Search Google Patents and USPTO with keywords and classifications."],
        ["Reading a patent", "Understand claims, drawings and prior art."],
        ["Prior art matrix", "Compare existing patents with your planned solution."],
        ["Patent search report", "Summarize what is protected and where there is room to innovate."]
      ] },
    { title: "Market analysis and specifications", summary: "Users, market size, competitors and design specs.",
      lessons: [
        ["Users and personas", "Describe your target users with evidence-based personas."],
        ["Market size", "Estimate TAM, SAM and SOM for your solution."],
        ["Competitor analysis", "Compare competitors on features, price and weaknesses."],
        ["Cost targets", "Set a target cost and price your solution must meet."],
        ["Design specifications", "Turn everything you've learned into measurable specs."]
      ] },
    { title: "Ideation", summary: "Generate many concepts and select the strongest.",
      lessons: [
        ["Brainstorming methods", "Brainwriting, mind maps and analogies."],
        ["SCAMPER and morphological charts", "Structured tools for new ideas."],
        ["Concept sketching", "Communicate concepts with annotated sketches."],
        ["Concept selection", "Use a weighted decision matrix against your specs."],
        ["Design review 1", "Present concepts and your selection to a review panel."]
      ] },
    { title: "Concept development", summary: "Break the design down, pick materials and analyze risk.",
      lessons: [
        ["Functional decomposition", "Break your solution into functions and subsystems."],
        ["Materials and components", "Select materials and parts using data."],
        ["Preliminary calculations", "Size key parts with engineering calculations."],
        ["Risk analysis (FMEA)", "Find what could fail and how to prevent it."],
        ["Preliminary design review", "Defend your developed concept."]
      ] },
    { title: "CAD development", summary: "Model your design so it can be built.",
      lessons: [
        ["CAD strategy", "Plan parts, assemblies and design intent."],
        ["Part modeling", "Model the main parts parametrically."],
        ["Assemblies", "Assemble and check fit and motion."],
        ["Technical drawings", "Create drawings someone else could build from."],
        ["CAD review", "Peer-review CAD models for errors."]
      ] },
    { title: "Prototype planning", summary: "Choose a prototype, budget it and plan the build safely.",
      lessons: [
        ["Types of prototypes", "Looks-like, works-like and proof-of-concept prototypes."],
        ["Bill of materials and budget", "List every part, source and cost."],
        ["Manufacturing processes", "3D printing, laser cutting, machining and more."],
        ["Build plan", "Sequence the build with milestones."],
        ["Shop and lab safety", "Safety procedures for the tools you'll use."]
      ] },
    { title: "Prototype build, sprint 1", summary: "Build the core of your prototype in focused sprints.",
      lessons: [
        ["Sprint planning", "Set goals for the week and plan daily tasks."],
        ["Build day 1", "Build and document progress."],
        ["Build day 2", "Build and document progress."],
        ["Build day 3", "Build and document progress."],
        ["Sprint review", "Show progress and adjust the plan."]
      ] },
    { title: "Prototype build, sprint 2", summary: "Keep building and solve problems as they appear.",
      lessons: [
        ["Sprint planning", "Reprioritize based on sprint 1."],
        ["Build day 1", "Build and document progress."],
        ["Build day 2", "Build and document progress."],
        ["Troubleshooting", "Diagnose problems systematically."],
        ["Critical design review", "Prove your prototype is ready to test."]
      ] },
    { title: "Integration", summary: "Bring subsystems together into one working prototype.",
      lessons: [
        ["Integration planning", "Plan how subsystems connect."],
        ["Electronics and controls", "Integrate sensors, power and code if your project needs them."],
        ["Integration build", "Assemble the full prototype."],
        ["Functional check", "Check every function works at a basic level."],
        ["Integration review", "Document what works and what needs fixing."]
      ] },
    { title: "Test planning", summary: "Design fair tests that measure your specifications.",
      lessons: [
        ["Writing a test plan", "Link every test to a specification."],
        ["Variables and procedures", "Control variables and write repeatable procedures."],
        ["Data collection", "Set up data sheets and measurement tools."],
        ["Statistics for engineers", "Mean, standard deviation and sample size."],
        ["Test readiness review", "Get your test plan approved."]
      ] },
    { title: "Testing and data analysis", summary: "Run tests, analyze data and compare to specs.",
      lessons: [
        ["Run tests, day 1", "Carry out your test procedures."],
        ["Run tests, day 2", "Complete trials and record observations."],
        ["Analyzing and graphing data", "Choose the right graphs and summarize results."],
        ["Results versus specifications", "Decide which specs you met and why."],
        ["Test results report", "Write up your results."]
      ] },
    { title: "Iteration", summary: "Improve the design based on evidence.",
      lessons: [
        ["Failure analysis", "Find root causes of failures in your tests."],
        ["Redesign", "Change the design to fix the root cause."],
        ["Rebuild", "Update the prototype."],
        ["Retest", "Run tests again and compare results."],
        ["Design freeze", "Finalize the design and document the changes."]
      ] },
    { title: "Technical documentation", summary: "Write a technical report and finish your portfolio.",
      lessons: [
        ["Technical report structure", "The sections of a professional engineering report."],
        ["Writing methods and results", "Write clear, precise methods and results."],
        ["Abstract and executive summary", "Summarize the whole project in one page."],
        ["Notebook audit", "Check your notebook is complete and signed."],
        ["Digital portfolio", "Publish your project as a portfolio page."]
      ] },
    { title: "Presentation development", summary: "Build a presentation that tells your project's story.",
      lessons: [
        ["Telling the engineering story", "Problem, process, solution, evidence."],
        ["Slide design", "Clear slides for technical audiences."],
        ["Presenting data", "Show results so the audience understands them quickly."],
        ["Rehearsal", "Practice, time and refine."],
        ["Peer review", "Give and receive structured feedback."]
      ] },
    { title: "Final presentations", summary: "Defend your work and look back on the capstone.",
      lessons: [
        ["Dress rehearsal", "Full run-through with questions."],
        ["Final presentations, day 1", "Present to the review panel."],
        ["Final presentations, day 2", "Present to the review panel."],
        ["Project showcase", "Show your prototype to the school community."],
        ["Capstone retrospective", "Reflect on the semester and plan what's next."]
      ] }
  ]
});
