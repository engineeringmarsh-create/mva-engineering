/* Advanced Engineering — Week 1: Capstone launch
   Lesson titles and focus statements come from course.js. */
MVA.registerWeek("advanced", 1, {

  /* ------------------------------------------------------------------ */
  1: {
    duration: "50 min",
    objectives: [
      "Explain what a capstone project is and how it differs from earlier engineering courses",
      "Describe the six phases of the semester and the major deliverable of each",
      "Identify how your work will be assessed",
      "List three areas of engineering you might want to work in this semester"
    ],
    reading: `
      <h3>This course is different</h3>
      <p>In Elements and Basic Engineering, your teacher defined the problems. In Advanced Engineering, <b>you</b> do. You'll identify a real problem, prove that it matters and spend the semester engineering a solution. There's no answer key. Your teacher acts more like a project manager or senior engineer: guiding, reviewing and pushing your thinking, not handing you steps.</p>
      <p>This is what a <b>capstone</b> is: the final project that pulls together everything you've learned. University engineering programs end with one, and so do many professional training programs. It's also the closest thing to real engineering work you'll do in high school.</p>
      <h3>The semester at a glance</h3>
      <ol>
        <li><b>Launch and problem identification (Weeks 1–2):</b> find a problem, interview the people who have it and write a justified problem statement. <i>Deliverable: problem approval presentation.</i></li>
        <li><b>Research, patents and markets (Weeks 3–5):</b> research the problem and existing solutions, search patents and analyze the market. <i>Deliverable: design specifications.</i></li>
        <li><b>Concept design (Weeks 6–8):</b> brainstorm, select and develop a concept, analyze risk and model it in CAD. <i>Deliverable: preliminary design review.</i></li>
        <li><b>Prototyping (Weeks 9–12):</b> plan, budget and build a working prototype. <i>Deliverable: critical design review.</i></li>
        <li><b>Testing and iteration (Weeks 13–15):</b> design tests, collect data and improve the design. <i>Deliverable: test results report.</i></li>
        <li><b>Documentation and presentation (Weeks 16–18):</b> technical report, portfolio and final presentation to a review panel.</li>
      </ol>
      <h3>How you're assessed</h3>
      <p>Your grade comes from four places: your <b>engineering notebook</b> (the running record of your process), <b>milestone deliverables</b> (the design reviews and reports above), <b>lesson completion</b> (verification codes for each lesson) and the <b>final presentation and report</b>. A prototype that doesn't fully work can still earn a high grade if your process, testing and documentation are excellent. Engineers are judged on the quality of their decisions, not luck.</p>
      <h3>What kind of project?</h3>
      <p>Almost any field works if you can justify a real need: robotics, aerospace, manufacturing, renewable energy, AI, transportation, infrastructure, biomedical engineering, assistive technology, agriculture, sports equipment and more. The best projects come from problems you've seen first-hand or that affect people you can actually talk to.</p>
      <h3>Solo or team</h3>
      <p>Projects can be individual or teams of two or three, with teacher approval. Teams take on bigger problems but must divide work clearly and document who did what.</p>`,
    vocab: [
      ["Capstone", "A culminating project that brings together everything learned in a program."],
      ["Deliverable", "A specific product due at a milestone, such as a report, model or presentation."],
      ["Design review", "A formal meeting where engineers present a design for critique and approval."],
      ["Milestone", "A key checkpoint in a project schedule."]
    ],
    check: [
      { q: "Who defines the problem in this course?",
        options: ["The teacher", "The student or team", "The textbook"],
        answer: 1, explain: "You identify and justify your own problem." },
      { q: "Your prototype works only partly. What matters most for your grade?",
        options: ["Whether it works perfectly", "The quality of your process, testing and documentation"],
        answer: 1, explain: "Engineers are judged on the quality of their decisions and evidence." }
    ],
    walkthrough: {
      intro: "<p>Build a personal semester roadmap so you know what's coming and when.</p>",
      steps: [
        { title: "Open the course map", body: "<p>Open the <a href=\"course.html?course=advanced\" target=\"_blank\">Advanced Engineering course page</a>. Note the six units and their week ranges.</p>" },
        { title: "Create the roadmap", body: "<p>In your notebook or a spreadsheet, make a table with columns: <b>Phase</b>, <b>Weeks</b>, <b>Major deliverable</b>, <b>Due date</b>. Fill in the six phases.</p>" },
        { title: "Add real dates", body: "<p>Use the school calendar to convert week numbers into actual dates. Mark holidays and exam weeks. These cut into build time, so plan for them now.</p>" },
        { title: "Flag the crunch points", body: "<p>Circle the two weeks you think will be most demanding. For most students, that's the end of prototyping and the testing phase. Write one sentence on how you'll prepare.</p>" }
      ]
    },
    example: {
      title: "Is this a capstone-ready idea?",
      problem: "<p>Evaluate three starting ideas: (a) <i>Build a robot.</i> (b) <i>Elderly residents at a local retirement community struggle to open medication bottles because of arthritis.</i> (c) <i>Design a faster car than a Tesla.</i></p>",
      steps: [
        "<b>(a)</b> names a solution with no problem, user or need. Not ready. Ask: a robot for whom, to solve what?",
        "<b>(b)</b> has a specific user group, a real need and people you can interview. Strong starting point.",
        "<b>(c)</b> isn't realistic for a semester or budget, and \"faster\" isn't tied to a user need. Not ready, though narrowing it (improving efficiency of a student's electric go-kart, say) could work.",
        "General test: Is there a real user? Can you talk to them? Can you prototype something meaningful in a semester with a school budget?"
      ],
      answer: "Only (b) is capstone-ready. (a) and (c) need to be reframed around a specific user and need.",
      takeaway: "Start from a problem and a person, not from a cool technology."
    },
    activity: {
      title: "Interest inventory and roadmap",
      time: "25 min",
      tools: ["Notebook or spreadsheet"],
      deliverable: "Semester roadmap and interest inventory",
      intro: "<p>Start thinking about where your project might come from.</p>",
      steps: [
        "Finish your semester roadmap from the walkthrough with real dates.",
        "List three fields of engineering you'd enjoy working in and why.",
        "For each field, list two places or groups of people where you could find real problems (a family member's job, a club, a local business, a hospital, your own daily routine).",
        "Write three \"I've noticed that…\" statements about problems you've personally seen. Don't propose solutions yet.",
        "Decide whether you'd prefer to work solo or on a team, and give one reason.",
        "Submit your roadmap and inventory in Canvas."
      ],
      rubric: "<ul><li>Roadmap with all six phases and real dates</li><li>Three fields with two problem sources each</li><li>Three solution-free \"I've noticed\" statements</li></ul>",
      extension: "Look up a past capstone or senior design project from a university engineering program. Note its problem, solution and one thing you'd want to copy in your own project."
    },
    reflection: [
      "What excites you most about defining your own problem, and what worries you?",
      "Why do you think a well-documented project with a partly working prototype can earn a higher grade than a working prototype with poor documentation?",
      "Which of your \"I've noticed\" statements are you most drawn to, and why?"
    ]
  },

  /* ------------------------------------------------------------------ */
  2: {
    duration: "45 min",
    objectives: [
      "Explain the legal and professional purpose of an engineering notebook",
      "Apply professional notebook rules, including signatures and witnesses",
      "Set up a notebook structure that supports a semester-long project",
      "Write a complete, defensible notebook entry"
    ],
    reading: `
      <h3>A notebook that could stand up in court</h3>
      <p>In Basic Engineering, your notebook was a learning tool. In a capstone, it's a <b>professional record</b>. Companies treat engineering notebooks as legal documents. They're used to prove when an idea was conceived, to defend patents, to investigate failures and to hand off work between engineers.</p>
      <p>Before 2013, the U.S. used a \"first to invent\" patent system, and dated, witnessed notebooks often decided who got a patent. The America Invents Act switched the U.S. to \"first inventor to file,\" but notebooks still matter. They're evidence of who actually invented something, they support patent applications and they're critical when a product fails and engineers need to reconstruct what happened.</p>
      <h3>Professional rules</h3>
      <ol>
        <li><b>Bound, numbered pages</b> (paper) or a locked, version-tracked document (digital). Nothing can be inserted or removed without a trace.</li>
        <li><b>Date and title every entry.</b></li>
        <li><b>Permanent ink.</b> Single-line strikethrough for errors, initialed.</li>
        <li><b>No blank space.</b> Draw a line through unused space at the end of an entry so nothing can be added later.</li>
        <li><b>Attach printouts permanently</b> (taped or glued), and sign across the edge of the attachment onto the page.</li>
        <li><b>Sign each page</b> when complete.</li>
        <li><b>Witness key pages.</b> For important ideas and results, have someone who understands the work but isn't on your team sign and date as a witness: <i>\"Read and understood by…\"</i></li>
      </ol>
      <h3>Structure for a semester project</h3>
      <p>Organize your notebook with a table of contents and a consistent entry format. A strong format is:</p>
      <ul>
        <li><b>Goal:</b> what you planned to do today</li>
        <li><b>Work:</b> what you actually did, with sketches, calculations and data</li>
        <li><b>Results and decisions:</b> what you learned and what you decided</li>
        <li><b>Next steps:</b> what happens next session</li>
      </ul>
      <p>Also keep sections for meeting notes, contacts (stakeholders you interview), sources and a running bill of materials.</p>`,
    vocab: [
      ["Witness", "A qualified person, not on your team, who signs to confirm they read and understood an entry."],
      ["Prior art", "Existing knowledge, products or patents that relate to an invention."],
      ["First inventor to file", "The U.S. patent rule since 2013: the first inventor to file a patent application has priority."],
      ["Traceability", "The ability to follow a design decision back to its reasons and evidence."]
    ],
    check: [
      { q: "Why draw a line through the unused space at the end of an entry?",
        options: ["It looks neater", "So nothing can be added later", "To save ink"],
        answer: 1, explain: "It protects the integrity of the record." },
      { q: "Who should witness a key notebook page?",
        options: ["Your teammate", "A qualified person who isn't on your team", "Nobody; signatures aren't needed"],
        answer: 1, explain: "A witness must be independent and able to understand the work." }
    ],
    walkthrough: {
      intro: "<p>Set up your capstone notebook. Your teacher will tell you whether to use paper or digital.</p>",
      steps: [
        { title: "Title page", body: "<p>Name, course, teacher, school year and a line for your eventual project title. Add: <i>\"If found, return to…\"</i></p>" },
        { title: "Table of contents", body: "<p>Reserve three pages (paper) or a linked heading list (digital). Columns: Date, Entry title, Page.</p>" },
        { title: "Section tabs", body: "<p>Mark sections at the back of the notebook for <b>Contacts</b>, <b>Sources</b> and <b>Bill of materials</b>, working from the back page forward.</p>" },
        { title: "Write today's entry", body: "<p>Date it and title it <i>Notebook setup and project interests</i>. Use the Goal / Work / Results and decisions / Next steps format. In Work, copy your three \"I've noticed\" statements from Day 1.</p>" },
        { title: "Close it professionally", body: "<p>Line out the remaining space, sign the page and add it to the table of contents.</p>" }
      ]
    },
    example: {
      title: "Would this entry hold up?",
      problem: "<p>Review this entry: <i>(no date) Talked to some nurses. They hate the IV poles. Idea: motorized pole. Printed a pic of one online (stuck in with a paperclip).</i></p>",
      steps: [
        "<b>No date</b> means it can't establish when the idea occurred. Add a date and title.",
        "<b>\"Some nurses\"</b> isn't traceable. Record names or roles, location and date of the interview in the Contacts section.",
        "<b>\"Hate the IV poles\"</b> is vague. Record the specific complaints, such as <i>3 of 4 nurses said poles tip when pushed over door thresholds.</i>",
        "<b>The idea jumps to a solution</b> before the problem is defined. That's fine to record, but label it as an early idea, not a decision.",
        "<b>The paperclipped printout</b> could be removed or swapped. Tape it in, sign across the edge and cite its source.",
        "<b>No signature or line-out.</b> Sign the page and line out unused space."
      ],
      answer: "No. It needs a date, traceable sources, specific evidence, a permanently attached and cited image, a signature and a lined-out end.",
      takeaway: "Write every entry as if someone will need to rely on it a year from now, because they might."
    },
    activity: {
      title: "Professional notebook setup",
      time: "20 min",
      tools: ["Bound notebook or digital notebook"],
      deliverable: "Photos or link showing setup and first entry",
      intro: "<p>Complete your notebook setup and get your first witness signature.</p>",
      steps: [
        "Complete the title page, table of contents and back sections from the walkthrough.",
        "Write a full entry for Day 1 (roadmap and interests) and Day 2 (notebook setup) using the four-part format.",
        "Sign each completed page and line out unused space.",
        "Ask a classmate who isn't your teammate to read your Day 1 entry and sign it as a witness.",
        "Submit photos or a view-only link in Canvas."
      ],
      rubric: "<ul><li>Complete setup with all sections</li><li>Two entries in the four-part format</li><li>Signatures, line-outs and one witness signature</li></ul>",
      extension: "Read about the Elisha Gray and Alexander Graham Bell telephone patent dispute and write a notebook entry on what it teaches about documentation."
    },
    reflection: [
      "Why does the U.S. switch to \"first inventor to file\" make it more important, not less, to keep good records and file early?",
      "Which professional notebook rule do you think students most often break, and why?",
      "How will you make sure you write entries during your work instead of from memory afterward?"
    ]
  },

  /* ------------------------------------------------------------------ */
  3: {
    duration: "50 min",
    objectives: [
      "Break a semester project into tasks and milestones",
      "Build a Gantt chart with task durations and dependencies",
      "Identify the critical path of a project",
      "Write SMART weekly goals"
    ],
    reading: `
      <h3>Why projects run late</h3>
      <p>Almost every student capstone runs into the same trap: plenty of time in September, panic in December. Professional engineers avoid this with <b>project management</b>: breaking big work into small tasks, estimating how long each takes and tracking progress against a schedule.</p>
      <h3>Work breakdown</h3>
      <p>Start by breaking the project into phases (you already have these from Day 1), then each phase into tasks small enough to finish in a few days. \"Build prototype\" is too big. \"Cut and drill the base plate\" is a task.</p>
      <h3>Gantt charts</h3>
      <p>A <b>Gantt chart</b> shows tasks as horizontal bars on a timeline. Each bar's length is the task's duration. Arrows show <b>dependencies</b>: tasks that can't start until another finishes. (You can't test a prototype before you build it.)</p>
      <h3>The critical path</h3>
      <p>The <b>critical path</b> is the longest chain of dependent tasks from start to finish. Any delay on the critical path delays the whole project. Tasks not on the critical path have <b>slack</b>: they can slip a little without affecting the end date. Knowing your critical path tells you where to focus.</p>
      <h3>Buffer</h3>
      <p>Things always take longer than expected, especially ordering parts and building. Add buffer time before major deadlines, typically 15–25% of the phase length.</p>
      <h3>SMART goals</h3>
      <p>Each week, write goals that are <b>S</b>pecific, <b>M</b>easurable, <b>A</b>chievable, <b>R</b>elevant and <b>T</b>ime-bound. \"Work on research\" isn't SMART. \"Find and summarize five credible sources on IV pole tip-over by Friday\" is.</p>`,
    vocab: [
      ["Gantt chart", "A bar chart showing project tasks on a timeline."],
      ["Dependency", "A task that can't start until another task is finished."],
      ["Critical path", "The longest chain of dependent tasks; it sets the project's minimum length."],
      ["Slack", "How long a task can be delayed without delaying the project."]
    ],
    check: [
      { q: "A task on the critical path is delayed 3 days. What happens?",
        options: ["Nothing, if other tasks finish early", "The whole project is delayed 3 days unless you recover time on the path"],
        answer: 1, explain: "Critical path tasks have zero slack." },
      { q: "Which is a SMART goal?",
        options: ["Make progress on CAD", "Finish the fully constrained base plate sketch in Onshape by Wednesday's class"],
        answer: 1, explain: "It's specific, measurable and has a deadline." }
    ],
    walkthrough: {
      intro: "<p>Build a simple Gantt chart in Google Sheets for a small example project: <b>building a birdhouse prototype in two weeks</b>. Then you'll do the same for your semester.</p>",
      steps: [
        { title: "List tasks and durations", body: "<p>In column A, list: Research designs (2 days), Sketch and dimension (1 day), CAD model (2 days), Buy materials (3 days), Cut parts (1 day), Assemble (1 day), Test outdoors (2 days), Write up (1 day).</p>" },
        { title: "Add dependencies", body: "<p>In column C, note what each depends on. Sketch depends on Research. CAD depends on Sketch. Buy materials depends on Sketch. Cut depends on CAD <i>and</i> Buy materials. Assemble depends on Cut. Test depends on Assemble. Write up depends on Test.</p>" },
        { title: "Draw the bars", body: "<p>Put day numbers 1–14 across row 1. Shade the cells for each task's days, starting each task after its dependencies end. Buy materials (days 4–6) can run at the same time as CAD (days 4–5).</p>" },
        { title: "Find the critical path", body: "<p>Trace the longest chain: Research (2) → Sketch (1) → Buy materials (3) → Cut (1) → Assemble (1) → Test (2) → Write up (1) = <b>11 days</b>. CAD isn't on the critical path; it has 1 day of slack.</p>" },
        { title: "Add buffer", body: "<p>You have 14 days and need 11, so there are 3 days of buffer. Place them before testing, the riskiest phase.</p>" }
      ]
    },
    example: {
      title: "Find the critical path",
      problem: "<p>Tasks: A = Design (4 days). B = Order motor (6 days, after A). C = Build frame (5 days, after A). D = Install motor (2 days, after B and C). E = Test (3 days, after D). What's the critical path and minimum project length? How much slack does C have?</p>",
      steps: [
        "Path A → B → D → E: 4 + 6 + 2 + 3 = 15 days.",
        "Path A → C → D → E: 4 + 5 + 2 + 3 = 14 days.",
        "The longest path is A → B → D → E, so it's the critical path, with a minimum length of 15 days.",
        "C's path is 1 day shorter, so C has 1 day of slack."
      ],
      answer: "Critical path A → B → D → E, 15 days. Task C has 1 day of slack.",
      takeaway: "Long-lead items like ordered parts are often on the critical path. Order early."
    },
    activity: {
      title: "Semester Gantt chart",
      time: "25 min",
      tools: ["Google Sheets or similar"],
      deliverable: "Gantt chart and Week 2 SMART goals",
      intro: "<p>You don't have a project yet, but you know the phases and deadlines. Build the framework now and fill in project-specific tasks as you go.</p>",
      steps: [
        "Create a sheet with weeks 1–18 across the top, using your real dates from the Day 1 roadmap.",
        "List the six phases and, under each, at least three tasks from the course map.",
        "Shade each task's weeks. Mark each milestone deliverable with a ◆ symbol.",
        "Add at least one week of buffer before the critical design review and before final presentations.",
        "Identify which tasks you think will be on the critical path and highlight them.",
        "Write three SMART goals for next week (Week 2: problem identification).",
        "Share a view-only link in Canvas."
      ],
      rubric: "<ul><li>18-week timeline with real dates</li><li>Six phases with tasks and milestones</li><li>Buffer and critical path marked</li><li>Three SMART goals</li></ul>",
      extension: "Try a free project management tool such as Trello or GitHub Projects and set up a board for your capstone."
    },
    reflection: [
      "Why do ordered parts often end up on the critical path?",
      "Think about a past project that ran late. What would a Gantt chart have shown you?",
      "Rewrite one of your usual vague goals as a SMART goal."
    ]
  },

  /* ------------------------------------------------------------------ */
  4: {
    duration: "50 min",
    objectives: [
      "Explain why engineers carry special ethical responsibility",
      "Summarize the fundamental canons of the NSPE Code of Ethics",
      "Analyze a real engineering ethics case",
      "Apply an ethical decision process to a dilemma"
    ],
    reading: `
      <h3>Why engineers need ethics</h3>
      <p>When engineers make mistakes, people can die. Bridges, buildings, medical devices, vehicles and software affect millions of people who have no way to check the engineering themselves. They trust that engineers did their jobs honestly and competently. That trust is why engineering has a formal code of ethics.</p>
      <h3>The NSPE Code of Ethics</h3>
      <p>The National Society of Professional Engineers (NSPE) Code of Ethics opens with six fundamental canons. Engineers, in fulfilling their professional duties, shall:</p>
      <ol>
        <li>Hold paramount the safety, health and welfare of the public.</li>
        <li>Perform services only in areas of their competence.</li>
        <li>Issue public statements only in an objective and truthful manner.</li>
        <li>Act for each employer or client as faithful agents or trustees.</li>
        <li>Avoid deceptive acts.</li>
        <li>Conduct themselves honorably, responsibly, ethically and lawfully so as to enhance the honor, reputation and usefulness of the profession.</li>
      </ol>
      <p>Notice the order. Public safety comes <b>first</b>, above loyalty to an employer or client.</p>
      <h3>Case: the Citicorp Center (1978)</h3>
      <p>A year after New York's 59-story Citicorp Center opened, structural engineer William LeMessurier learned, prompted by questions from an engineering student, that the building's bracing was more vulnerable to wind from certain angles than his team had calculated. A change from welded to bolted joints during construction made it worse. A strong enough storm could topple it.</p>
      <p>LeMessurier could have stayed silent. Instead, he told the owners, risking his reputation and career. Crews secretly welded steel plates over the joints at night during hurricane season, and emergency evacuation plans were prepared. The building was fixed, and LeMessurier's honesty is now taught as a model of ethical engineering.</p>
      <h3>Case: the Hyatt Regency walkway collapse (1981)</h3>
      <p>In Kansas City, two suspended walkways in a hotel atrium collapsed during a crowded event, killing 114 people. A design change to the hanger rods had doubled the load on a critical connection, and the change was approved without proper review. The engineers of record lost their licenses. The lesson: you are responsible for what you sign, including changes.</p>
      <h3>Ethics in your capstone</h3>
      <p>Your capstone carries real ethical questions: honestly reporting test data (including failures), citing sources, respecting the privacy of people you interview, designing safely and giving credit to teammates.</p>`,
    vocab: [
      ["Code of ethics", "A formal set of principles guiding professional conduct."],
      ["Hold paramount", "Treat as the highest priority, above all others."],
      ["Engineer of record", "The licensed engineer legally responsible for a design."],
      ["Whistleblowing", "Reporting unsafe or unethical practices, often outside normal channels."]
    ],
    check: [
      { q: "According to the NSPE canons, what comes first?",
        options: ["Loyalty to the employer", "Public safety, health and welfare", "Keeping the project on budget"],
        answer: 1, explain: "The first canon makes public safety paramount." },
      { q: "Your test data shows your device fails 2 of 10 trials. What should your report say?",
        options: ["Report only the 8 successes", "Report all 10 trials and analyze the failures"],
        answer: 1, explain: "Canons 3 and 5 require truthful, non-deceptive reporting." }
    ],
    walkthrough: {
      intro: "<p>Use this five-step ethical decision process to work through a dilemma together.</p><p><b>Dilemma:</b> You're on a capstone team. The final presentation is in two days. During a last test, your prototype's battery pack gets hot enough to melt plastic. Your teammate says, \"It only happened once. Let's not mention it. The judges won't test it.\"</p>",
      steps: [
        { title: "State the facts", body: "<p>Write only what you know: the battery overheated once, enough to melt plastic. You don't know why or how often it will recur.</p>" },
        { title: "Identify stakeholders", body: "<p>List everyone affected: you, your teammate, the judges, anyone who might use or handle the prototype, future users if the design were developed further.</p>" },
        { title: "Identify the ethical issues", body: "<p>Safety (canon 1): an overheating battery is a fire and burn risk. Honesty (canons 3 and 5): hiding a known failure is deceptive.</p>" },
        { title: "List options and consequences", body: "<p>(a) Hide it: risk of injury and an integrity violation if discovered. (b) Disclose it and present the failure analysis: lower demo polish but honest. (c) Disable the battery for the demo and explain why: safe and honest.</p>" },
        { title: "Decide and justify", body: "<p>Write your choice and cite the canon(s) that support it. Most engineers would choose (b) or (c). Presenting a failure and your analysis of it often impresses judges more than a flawless demo.</p>" }
      ]
    },
    example: {
      title: "Apply the canons",
      problem: "<p>An engineer at a small firm is asked to stamp (approve) electrical drawings for a hospital. Her expertise is structural engineering, but her boss says, \"You're licensed; just sign it so we don't lose the client.\" Which canons apply, and what should she do?</p>",
      steps: [
        "<b>Canon 2 (competence):</b> she would be approving work outside her area of expertise.",
        "<b>Canon 1 (public safety):</b> faulty hospital electrical systems could endanger patients.",
        "<b>Canon 4 (faithful agent)</b> doesn't override canons 1 and 2. Loyalty to her employer ranks below safety and competence.",
        "<b>Action:</b> decline to stamp the drawings, explain why in writing and recommend the firm hire or consult a licensed electrical engineer."
      ],
      answer: "Canons 1 and 2 apply. She should refuse to stamp the drawings and recommend a qualified electrical engineer review them.",
      takeaway: "When canons seem to conflict, the order matters: public safety first."
    },
    activity: {
      title: "Ethics case analysis",
      time: "25 min",
      tools: ["Internet", "Notebook"],
      deliverable: "One-page case analysis",
      intro: "<p>Research one real engineering ethics case and analyze it with the canons.</p>",
      steps: [
        "Choose a case: the Challenger disaster (1986), the Ford Pinto fuel tank, the Volkswagen emissions scandal, the Boeing 737 MAX, the Flint water crisis, or another approved by your teacher.",
        "Find at least two credible sources. Record them in your notebook's Sources section.",
        "Summarize the case: what happened, who was involved and what the consequences were.",
        "Identify which NSPE canons were upheld or violated, with specific evidence.",
        "Explain what an engineer could have done differently at one key decision point.",
        "Write one lesson from the case that applies to your capstone.",
        "Submit your analysis in Canvas."
      ],
      rubric: "<ul><li>Accurate summary with two credible sources</li><li>Canons correctly applied with evidence</li><li>A specific alternative decision</li><li>A lesson connected to your own project</li></ul>",
      extension: "Read the full NSPE Code of Ethics, including the Rules of Practice. Find one rule that surprised you."
    },
    reflection: [
      "Why do you think public safety is placed above loyalty to an employer?",
      "What made LeMessurier's choice difficult, and what made it right?",
      "Name one ethical situation that could realistically come up during your capstone, and how you'll handle it."
    ],
    resources: [
      { label: "NSPE Code of Ethics", url: "https://www.nspe.org/resources/ethics/code-ethics" }
    ]
  },

  /* ------------------------------------------------------------------ */
  5: {
    duration: "50 min (plus observation time outside class)",
    objectives: [
      "Use observation techniques to find real problems",
      "Write problem observations without jumping to solutions",
      "Log at least ten problems with evidence",
      "Rank problems using capstone feasibility criteria"
    ],
    reading: `
      <h3>Problems are everywhere, but hard to see</h3>
      <p>People adapt to problems so well that they stop noticing them. They prop doors with wedges, tape over broken parts and develop workarounds without thinking. These workarounds are clues. Professional designers call this process <b>need-finding</b>.</p>
      <h3>Observation techniques</h3>
      <ul>
        <li><b>Look for workarounds.</b> Tape, rubber bands, sticky notes, handwritten signs and improvised tools all mean something isn't working as designed.</li>
        <li><b>Watch for frustration.</b> Sighs, repeated attempts, people giving up on a task.</li>
        <li><b>Follow a process end to end.</b> Shadow someone through a task (making breakfast, setting up for practice, closing a store) and note every pain point.</li>
        <li><b>Ask \"what's annoying?\"</b> Ask people what wastes their time, what they'd fix if they could, or what they've stopped trying to do.</li>
        <li><b>Look at the edges.</b> Many problems affect people with disabilities, older adults, children or people in specific jobs. These users are often overlooked by mainstream products.</li>
      </ul>
      <h3>Write observations, not solutions</h3>
      <p>Record what you saw, who was affected and why it matters. Resist writing solutions. \"Need a better backpack\" is a solution in disguise. \"Students carrying instruments and sports gear can't fit both in a locker, so they leave equipment in the hallway\" is an observation.</p>
      <h3>Capstone feasibility</h3>
      <p>Not every real problem makes a good capstone. Good candidates:</p>
      <ul>
        <li>Affect real people you can <b>access and interview</b></li>
        <li>Are <b>significant</b>, with consequences you can document</li>
        <li>Allow a <b>meaningful prototype</b> in one semester on a school budget</li>
        <li>Are <b>safe</b> to prototype and test</li>
        <li>Genuinely <b>interest you</b>. You'll spend 18 weeks on this.</li>
      </ul>`,
    vocab: [
      ["Need-finding", "Discovering unmet needs by observing and talking to people."],
      ["Workaround", "An improvised fix people use when something doesn't work well."],
      ["Pain point", "A specific moment of frustration in a process."],
      ["Feasibility", "Whether a project can realistically be completed with the time, money and resources available."]
    ],
    check: [
      { q: "Which is an observation rather than a disguised solution?",
        options: ["Need an app for the cafeteria line", "The cafeteria line takes 18 minutes at peak, so students have 7 minutes left to eat"],
        answer: 1, explain: "It describes what happens and why it matters, with evidence." },
      { q: "You notice teachers taping cardboard over a classroom projector's fan vent. That's an example of…",
        options: ["A workaround", "A dependency", "Prior art"], answer: 0,
        explain: "Improvised fixes signal an unmet need." }
    ],
    walkthrough: {
      intro: "<p>Practice observation on a familiar environment: <b>your school</b>. Spend 15 minutes walking or recalling a typical day.</p>",
      steps: [
        { title: "Choose a process", body: "<p>Pick one routine: arriving at school, changing classes, lunch, after-school practice or dorm life. Write it at the top of a new notebook entry.</p>" },
        { title: "Map the steps", body: "<p>List every step of the process in order. For arrival: parking or drop-off, walking in, security, lockers, getting to first period.</p>" },
        { title: "Mark pain points", body: "<p>Next to each step, mark anything slow, frustrating, unsafe or confusing. Note workarounds you've seen.</p>" },
        { title: "Write observations", body: "<p>Turn your top two pain points into observation statements: <i>who</i> is affected, <i>what</i> happens, <i>why it matters</i>. No solutions.</p>" },
        { title: "Add evidence", body: "<p>For each, write one way you could measure it: time it, count it, survey people or photograph it.</p>" }
      ]
    },
    example: {
      title: "Rank three problems for capstone feasibility",
      problem: "<p>Score each problem 1–5 on Access, Significance, Prototype feasibility, Safety and Interest, then total: (A) <i>Rowers on the school crew team can't tell if their stroke timing matches teammates' until the coach reviews video later.</i> (B) <i>Hospitals lose millions each year to equipment theft.</i> (C) <i>A student's grandfather with Parkinson's spills drinks because of hand tremors.</i></p>",
      steps: [
        "<b>A (crew timing):</b> Access 5 (teammates), Significance 3, Prototype 4 (sensors and feedback), Safety 4, Interest 4 = <b>20</b>.",
        "<b>B (hospital theft):</b> Access 1 (hard to reach hospital staff), Significance 4, Prototype 2 (needs hospital systems), Safety 5, Interest 3 = <b>15</b>.",
        "<b>C (tremor spills):</b> Access 4 (family member plus support groups), Significance 4, Prototype 4, Safety 4, Interest 5 = <b>21</b>.",
        "C and A are both strong. B is a real problem but a poor capstone fit because of access and prototype limits."
      ],
      answer: "C (21) and A (20) are strong capstone candidates. B (15) is a real problem but not feasible for this course.",
      takeaway: "Access to real users is often the deciding factor. If you can't talk to the people who have the problem, choose another problem."
    },
    activity: {
      title: "Problem log: ten real problems",
      time: "Class time plus one week of observation",
      tools: ["Notebook", "Phone camera (respect privacy)"],
      deliverable: "Problem log with 10 entries and top-3 ranking",
      intro: "<p>Over the next week, observe your world and log ten real problems. This log is the starting point for your capstone.</p>",
      steps: [
        "Create a problem log table: <b>Date</b>, <b>Where</b>, <b>Observation (who / what / why it matters)</b>, <b>Evidence</b>, <b>Field of engineering</b>.",
        "Log at least <b>ten</b> problems from at least <b>three different settings</b> (school, home, a job, a sport, a community place).",
        "Include at least <b>two workarounds</b> you observed, with a photo or sketch. Don't photograph people without permission.",
        "Talk to at least <b>two people</b> about problems they face and log what they say.",
        "Score your ten problems on the five feasibility criteria (1–5 each) and rank your top three.",
        "Write a short paragraph on your number-one problem: why it's significant and who you'd interview next week.",
        "Submit your log in Canvas."
      ],
      rubric: "<ul><li>10 solution-free observations from 3+ settings</li><li>Evidence for each</li><li>2 workarounds and 2 conversations</li><li>Feasibility scoring and top-3 ranking with a justified first choice</li></ul>",
      extension: "Find out whether your top problem affects people beyond your community. Find one statistic or article that shows its scale."
    },
    reflection: [
      "What's the most surprising problem you've noticed so far, and why had you never noticed it before?",
      "Why is it so tempting to jump to solutions, and how will you resist it?",
      "Which feasibility criterion do you think will be hardest for your top problem to meet?"
    ]
  }
});
