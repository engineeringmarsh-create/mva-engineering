/* Elements of Engineering — course map (18 weeks x 5 lessons)
   Each lesson entry is [title, focus]. Full lesson content lives in week-XX.js.
   When you finish writing a week file, add its number to publishedWeeks. */
MVA.registerCourse({
  id: "elements",
  code: "EE",
  title: "Elements of Engineering",
  level: "Introductory",
  audience: "No experience needed",
  tagline: "Build, test and improve: a first look at how engineers solve problems.",
  description:
    "A hands-on introduction to engineering. You'll explore civil, mechanical and aerospace engineering through short design challenges, simple builds, career spotlights and your first 3D models in Tinkercad. The focus is creativity and learning to think like an engineer, not memorizing formulas.",
  disciplines: ["Civil", "Mechanical", "Aerospace"],
  tools: ["Tinkercad", "Engineering notebook", "Bridge simulator", "Basic craft materials"],
  outcomes: [
    "Use a simple engineering design process to solve open-ended problems",
    "Sketch ideas and turn them into 3D models in Tinkercad",
    "Explain the basic science behind structures, machines and flight",
    "Describe what civil, mechanical and aerospace engineers do and how to become one",
    "Present and defend a design you created"
  ],
  publishedWeeks: [1],
  units: [
    { title: "Thinking like an engineer", weeks: [1, 2, 3] },
    { title: "Civil engineering", weeks: [4, 5, 6, 7] },
    { title: "Mechanical engineering", weeks: [8, 9, 10, 11] },
    { title: "Aerospace engineering", weeks: [12, 13, 14, 15] },
    { title: "Final design challenge", weeks: [16, 17, 18] }
  ],
  weeks: [
    { title: "What is engineering?", summary: "Meet the field, the design process and your engineering notebook.",
      lessons: [
        ["Welcome to engineering", "What engineers do, how this course works and how to complete a lesson."],
        ["Engineering is everywhere", "Spot the engineered objects around you and the problems they solve."],
        ["The engineering design process", "Ask, imagine, plan, create, test, improve: the loop engineers use."],
        ["Your engineering notebook", "How engineers record ideas, sketches and test results."],
        ["Challenge: the paper tower", "Use the design process to build the tallest free-standing paper tower."]
      ] },
    { title: "Problems, ideas and sketches", summary: "Define problems clearly, brainstorm and communicate ideas with sketches.",
      lessons: [
        ["Criteria and constraints", "Turn a vague problem into a clear goal with rules."],
        ["Brainstorming like an engineer", "Generate many ideas quickly and pick the most promising."],
        ["Sketching 101: isometric views", "Draw 3D objects on paper with isometric sketching."],
        ["Measuring and units", "Measure accurately with rulers and use metric units."],
        ["Challenge: design a phone stand", "Define, brainstorm and sketch a phone stand that meets criteria."]
      ] },
    { title: "Getting started with Tinkercad", summary: "Create your first 3D models in a browser-based CAD tool.",
      lessons: [
        ["What is CAD?", "Why engineers model on computers, and setting up your Tinkercad account."],
        ["Shapes, moving and sizing", "Use the workplane, basic shapes and the ruler to place parts exactly."],
        ["Grouping and holes", "Combine solids and holes to make complex shapes."],
        ["Align, duplicate and mirror", "Speed up modeling with precision tools."],
        ["Project: name keychain", "Model a custom keychain that meets size criteria."]
      ] },
    { title: "Structures and forces", summary: "What civil engineers do and how structures carry loads.",
      lessons: [
        ["Meet civil engineering", "Roads, bridges, buildings and water: the systems civil engineers design."],
        ["Tension and compression", "The two forces that push and pull on every structure."],
        ["Why triangles are strong", "How triangles and trusses keep shapes from collapsing."],
        ["Loads on a structure", "Dead loads, live loads and environmental loads."],
        ["Challenge: truss test", "Build and test a small truss and record the load it holds."]
      ] },
    { title: "Bridges", summary: "Bridge types, famous failures and your first bridge design.",
      lessons: [
        ["Five types of bridges", "Beam, arch, truss, suspension and cable-stayed bridges."],
        ["Learning from bridge failures", "What Tacoma Narrows and other failures taught engineers."],
        ["Bridge simulator", "Design and load-test a bridge in an online simulator."],
        ["Modeling a bridge in Tinkercad", "Turn your best simulator design into a 3D model."],
        ["Challenge: bridge load test", "Build or simulate your bridge and calculate strength-to-weight."]
      ] },
    { title: "Buildings and cities", summary: "Tall buildings, earthquakes and the infrastructure that runs a city.",
      lessons: [
        ["How skyscrapers stand up", "Foundations, frames and cores in tall buildings."],
        ["Earthquakes and wind", "How engineers keep buildings safe when the ground shakes."],
        ["Roads, water and power", "The hidden infrastructure systems of a city."],
        ["Design a shake-safe tower", "Model an earthquake-resistant tower in Tinkercad."],
        ["Challenge: shake table test", "Test a tower on a shake table and improve it."]
      ] },
    { title: "Civil engineering project", summary: "Design a pedestrian bridge for campus from brief to presentation.",
      lessons: [
        ["Project brief: campus footbridge", "Read the brief and identify criteria and constraints."],
        ["Research and sketches", "Study similar bridges and sketch three concepts."],
        ["Build the Tinkercad model", "Model your chosen concept to scale."],
        ["Present and peer review", "Present your bridge and give feedback to classmates."],
        ["Careers in civil engineering", "Jobs, degrees and a day in the life of a civil engineer."]
      ] },
    { title: "Simple machines", summary: "What mechanical engineers do and the six simple machines.",
      lessons: [
        ["Meet mechanical engineering", "Engines, robots and products: what mechanical engineers design."],
        ["Levers", "First, second and third class levers and mechanical advantage."],
        ["Wheels, axles and pulleys", "How rotating machines trade force for distance."],
        ["Ramps, wedges and screws", "The inclined plane family of simple machines."],
        ["Challenge: chain-reaction machine", "Sketch a chain-reaction machine using three simple machines."]
      ] },
    { title: "Motion and energy", summary: "Energy, friction and speed in moving machines.",
      lessons: [
        ["Forms of energy", "How energy changes form inside machines."],
        ["Potential and kinetic energy", "Stored energy, motion energy and how they trade off."],
        ["Friction", "When friction helps, when it hurts, and how to control it."],
        ["Measuring speed", "Measure distance and time to calculate speed."],
        ["Challenge: rubber-band car", "Design a rubber-band powered car and measure its speed."]
      ] },
    { title: "Gears and mechanisms", summary: "Gears, linkages and cams that make products move.",
      lessons: [
        ["Gears and gear ratios", "How gears change speed and turning force."],
        ["Linkages and cams", "Mechanisms that change one kind of motion into another."],
        ["Gear train in Tinkercad", "Model a working gear train with the gear shape generator."],
        ["Mechanisms in everyday products", "Take apart (virtually) a product and find its mechanisms."],
        ["Project: mechanical toy", "Design a toy that uses at least one mechanism."]
      ] },
    { title: "Mechanical engineering project", summary: "Design an assistive gadget that makes a daily task easier.",
      lessons: [
        ["Project brief: helpful gadget", "Choose a user and a daily task to make easier."],
        ["Research and sketches", "Interview your user and sketch three concepts."],
        ["Build the Tinkercad model", "Model your gadget with moving or fitting parts."],
        ["Present and peer review", "Present your gadget and gather feedback."],
        ["Careers in mechanical engineering", "Jobs, degrees and a day in the life of a mechanical engineer."]
      ] },
    { title: "How things fly", summary: "What aerospace engineers do and the four forces of flight.",
      lessons: [
        ["Meet aerospace engineering", "Aircraft, rockets, satellites and drones."],
        ["The four forces of flight", "Lift, weight, thrust and drag."],
        ["Wings and airfoils", "How a wing's shape makes lift."],
        ["Steering an airplane", "Ailerons, elevator and rudder: pitch, roll and yaw."],
        ["Challenge: paper airplane trials", "Run fair tests to find the best paper airplane design."]
      ] },
    { title: "Rockets and space", summary: "How rockets work and why they stay stable.",
      lessons: [
        ["Action and reaction", "Newton's third law and rocket thrust."],
        ["Parts of a rocket", "Nose cone, body, fins and motor; center of gravity and center of pressure."],
        ["A short history of spaceflight", "From Sputnik to Artemis."],
        ["Design a rocket in Tinkercad", "Model a stable rocket with correct fin placement."],
        ["Challenge: straw rockets", "Build, launch and improve a straw rocket."]
      ] },
    { title: "Drones, satellites and landers", summary: "Uncrewed flight and landing safely on another world.",
      lessons: [
        ["How drones fly", "Rotors, thrust and control in a quadcopter."],
        ["Satellites and orbits", "Why satellites don't fall and what they do for us."],
        ["Planning a mission", "Goals, constraints and trade-offs in a space mission."],
        ["Design a satellite in Tinkercad", "Model a satellite with power, communication and payload parts."],
        ["Challenge: Mars lander", "Design a lander that protects its cargo during a drop test."]
      ] },
    { title: "Aerospace engineering project", summary: "Design an aircraft or spacecraft for a specific mission.",
      lessons: [
        ["Project brief: mission vehicle", "Choose a mission and list what your vehicle must do."],
        ["Research", "Study real vehicles that fly similar missions."],
        ["Build the Tinkercad model", "Model your vehicle and label its key systems."],
        ["Present and peer review", "Pitch your vehicle to a mission review board."],
        ["Careers in aerospace engineering", "Jobs, degrees and a day in the life of an aerospace engineer."]
      ] },
    { title: "Final challenge: find a problem", summary: "Choose a real problem and plan your own solution.",
      lessons: [
        ["Final challenge overview", "What you'll make, how it's graded and the timeline."],
        ["Finding a problem worth solving", "Look around school and home for problems you could fix."],
        ["Research your problem", "Who has this problem, and what solutions already exist?"],
        ["Brainstorm solutions", "Generate and compare at least five ideas."],
        ["Write your proposal", "Summarize your problem, criteria, constraints and chosen idea."]
      ] },
    { title: "Final challenge: design and test", summary: "Sketch, model, test and improve your solution.",
      lessons: [
        ["Detailed sketches", "Draw your solution from several views with dimensions."],
        ["Tinkercad model, part 1", "Build the main body of your design."],
        ["Tinkercad model, part 2", "Add details, fit and finish."],
        ["Testing and feedback", "Test against your criteria and collect user feedback."],
        ["Improve your design", "Make at least one evidence-based improvement."]
      ] },
    { title: "Final challenge: showcase", summary: "Present your work and look back on the course.",
      lessons: [
        ["Build your presentation", "Tell the story of your design from problem to solution."],
        ["Practice and polish", "Rehearse, time yourself and refine your slides."],
        ["Showcase, day 1", "Present to the class and answer questions."],
        ["Showcase, day 2", "Present to the class and give peer feedback."],
        ["Looking back, looking ahead", "Reflect on your growth and plan your next engineering course."]
      ] }
  ]
});
