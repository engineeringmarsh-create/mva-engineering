/* Elements of Engineering — Week 1: What is engineering?
   Lesson titles and focus statements come from course.js. */
MVA.registerWeek("elements", 1, {

  /* ------------------------------------------------------------------ */
  1: {
    duration: "40 min",
    objectives: [
      "Describe what engineers do in one or two sentences",
      "Name the three branches of engineering you'll explore in this course",
      "Explain how a lesson on this site works, from objectives to completion code"
    ],
    reading: `
      <h3>Welcome</h3>
      <p>Look around you. The chair you're sitting on, the lights overhead, the building around you and the device you're reading this on were all designed by engineers. Somebody had to figure out how to make each one strong enough, safe enough, cheap enough and useful enough. That's engineering.</p>
      <h3>So what do engineers actually do?</h3>
      <p><b>Engineers solve problems by designing things.</b> They use science, math and a lot of creativity. But mostly they follow a habit: understand the problem, come up with ideas, build something, test it and make it better.</p>
      <p>You don't need to be a math genius to start. Curiosity, patience and willingness to try again after something fails matter more. Every engineer you'll read about this semester failed many times before succeeding.</p>
      <h3>Three branches you'll explore</h3>
      <ul>
        <li><b>Civil engineering:</b> bridges, buildings, roads and the systems that bring water and power to cities.</li>
        <li><b>Mechanical engineering:</b> machines and moving things, from bicycles and roller coasters to robots.</li>
        <li><b>Aerospace engineering:</b> airplanes, rockets, drones and spacecraft.</li>
      </ul>
      <p>You'll also learn <b>Tinkercad</b>, a free program for building 3D models on the computer. By the end of the course, you'll design and present a solution to a problem you choose yourself.</p>
      <h3>How lessons work</h3>
      <p>Every lesson on this site has seven sections. Use the list on the left (or the tabs at the top on a phone) to move between them:</p>
      <ol>
        <li><b>Learning objectives:</b> what you'll be able to do</li>
        <li><b>Reading and instruction:</b> the main ideas (you're here now)</li>
        <li><b>Guided walkthrough:</b> step-by-step practice</li>
        <li><b>Worked example:</b> a problem solved for you</li>
        <li><b>Activity:</b> your turn</li>
        <li><b>Reflection:</b> short questions about what you learned</li>
        <li><b>Completion:</b> your code for Canvas</li>
      </ol>`,
    vocab: [
      ["Engineer", "A person who designs solutions to problems using science, math and creativity."],
      ["Design", "To plan how something will look and work before it is made."],
      ["Civil engineering", "Designing bridges, buildings, roads and city systems."],
      ["Aerospace engineering", "Designing things that fly, like airplanes and rockets."]
    ],
    check: [
      { q: "Which sentence best describes what engineers do?",
        options: ["They memorize science facts", "They design solutions to problems", "They only work with engines"],
        answer: 1, explain: "Engineers use what they know to design things that solve problems." },
      { q: "A student designs a better roller coaster loop. Which branch is that mostly?",
        options: ["Civil", "Mechanical", "Aerospace"],
        answer: 1, explain: "Roller coasters are machines with moving parts, so they're mainly mechanical engineering, with civil engineers designing the supports." }
    ],
    walkthrough: {
      intro: "<p>Take a tour of this site so you can find everything on your own later.</p>",
      steps: [
        { title: "Find your course page", body: "<p>Open the <a href=\"course.html?course=elements\" target=\"_blank\">Elements of Engineering course page</a> in a new tab. Scroll through the course map. How many units are there? Write the names of the three engineering units in your notebook.</p>" },
        { title: "Open a week", body: "<p>Click <b>Week 1</b>. You'll see the five lessons for this week. Notice the status labels: <i>Ready</i>, <i>Complete</i> or <i>In development</i>.</p>" },
        { title: "Check the resource library", body: "<p>Open the <a href=\"resources.html\" target=\"_blank\">Resource library</a>. Find the link to Tinkercad. You'll use it in Week 3.</p>" },
        { title: "Find your progress", body: "<p>Open <a href=\"progress.html\" target=\"_blank\">My progress</a>. Every square is a lesson. After you finish this lesson, come back and you'll see your first square filled in.</p>" }
      ]
    },
    example: {
      title: "Is it engineered?",
      problem: "<p>Decide whether each item was designed by engineers: (a) a pencil, (b) a tree, (c) a pair of sneakers, (d) a river, (e) a dam on a river.</p>",
      steps: [
        "<b>Pencil:</b> yes. Someone designed the wood, the graphite core and the eraser, and a machine to make millions of them.",
        "<b>Tree:</b> no. It grew naturally, though an engineer might design a way to plant thousands of them.",
        "<b>Sneakers:</b> yes. Engineers design the sole's cushioning, grip and the materials.",
        "<b>River:</b> no. It's natural.",
        "<b>Dam:</b> yes. Civil engineers designed it to hold back water and often to make electricity."
      ],
      answer: "The pencil, sneakers and dam are engineered. The tree and river are natural.",
      takeaway: "If a person had to plan how it would work before it existed, it's engineered."
    },
    activity: {
      title: "Engineer introduction card",
      time: "15 min",
      tools: ["Notebook or Google Slides"],
      deliverable: "One-page introduction card",
      intro: "<p>Introduce yourself as a future engineer.</p>",
      steps: [
        "Write your name and one thing you've built, fixed or taken apart before (a LEGO set, a bike, a computer, a fort, anything).",
        "Name one object you use every day and say what problem it solves.",
        "Pick which branch interests you most right now (civil, mechanical or aerospace) and explain why in one sentence.",
        "Write one question you hope this course answers.",
        "Submit a photo or the slide in Canvas."
      ],
      rubric: "<ul><li>All four parts answered</li><li>Complete sentences</li></ul>",
      extension: "Find a video of an engineer from one of the three branches describing their job. Write down the job title and one surprising thing they said."
    },
    reflection: [
      "In your own words, what does an engineer do?",
      "Which branch of engineering are you most excited to learn about, and why?",
      "What's one thing you're nervous about or curious about in this course?"
    ]
  },

  /* ------------------------------------------------------------------ */
  2: {
    duration: "40 min",
    objectives: [
      "Identify engineered objects in your environment",
      "Describe the problem an engineered object solves",
      "Connect objects to the branch of engineering that designed them"
    ],
    reading: `
      <h3>Everything around you started as a problem</h3>
      <p>Before there were backpacks, people carried things in their arms. Before there were bridges, people waded across rivers. Every engineered object exists because someone noticed a problem and designed a way to solve it.</p>
      <p>When you look at an object like an engineer, ask three questions:</p>
      <ol>
        <li><b>What problem does it solve?</b></li>
        <li><b>Who uses it?</b></li>
        <li><b>What makes it work well (or badly)?</b></li>
      </ol>
      <h3>Example: the humble backpack</h3>
      <p><b>Problem:</b> students need to carry heavy books and laptops without hurting their backs. <b>Users:</b> students, hikers, travelers. <b>What makes it work:</b> two padded straps spread the weight across both shoulders, the zipper keeps things from falling out and the strong fabric doesn't rip.</p>
      <p>Notice that someone had to make decisions about every one of those features. Why two straps instead of one? Why nylon instead of cotton? Those are engineering decisions.</p>
      <h3>Big and small</h3>
      <p>Engineering isn't only gadgets. The road outside your school was designed by civil engineers to drain rainwater and carry heavy buses. The air conditioning was designed by mechanical engineers. The airplane that flies overhead was designed by aerospace engineers. Some engineered things are so big we stop noticing them.</p>`,
    vocab: [
      ["Engineered object", "Anything people designed and made to solve a problem."],
      ["User", "The person who will use a design."],
      ["Feature", "A part or quality of a design that helps it work, like a padded strap."],
      ["Infrastructure", "The large systems a community needs, like roads, bridges, water and power."]
    ],
    check: [
      { q: "What's the first question to ask when looking at an object like an engineer?",
        options: ["How much did it cost?", "What problem does it solve?", "What color is it?"],
        answer: 1, explain: "Every design starts with a problem." },
      { q: "The road outside your school is an example of…",
        options: ["Infrastructure", "Nature", "A simple machine"],
        answer: 0, explain: "Roads, bridges, water and power systems are infrastructure designed by civil engineers." }
    ],
    walkthrough: {
      intro: "<p>Analyze one object together using the three engineer questions. Grab a water bottle (or picture one).</p>",
      steps: [
        { title: "What problem does it solve?", body: "<p>Write: <i>People need to carry drinking water with them without spilling it.</i></p>" },
        { title: "Who uses it?", body: "<p>Write at least two kinds of users: students, athletes, hikers.</p>" },
        { title: "What makes it work well?", body: "<p>List three features and why each matters. For example: screw lid (doesn't leak), insulated walls (keeps water cold), flat bottom (stands up on a desk).</p>" },
        { title: "What could be better?", body: "<p>Engineers always look for improvements. Write one thing that bugs you about your bottle, and one idea to fix it. This is how new products start.</p>" }
      ]
    },
    example: {
      title: "Analyze a bike helmet",
      problem: "<p>Use the three engineer questions to analyze a bike helmet, then suggest one improvement.</p>",
      steps: [
        "<b>Problem:</b> riders can hit their heads in a crash, causing serious injury.",
        "<b>Users:</b> kids, commuters, mountain bikers, delivery riders.",
        "<b>Features:</b> a foam liner that crushes to absorb the impact, a hard plastic shell that spreads the force and slides on pavement, adjustable straps so it stays on, and vents to keep the rider cool.",
        "<b>Improvement:</b> many people don't wear helmets because they're bulky to carry. A helmet that folds flat would fix that."
      ],
      answer: "A helmet solves head injury in crashes using a crushable liner, a hard shell, straps and vents. A foldable version could get more people to wear one.",
      takeaway: "Every feature in a good design is there for a reason. Your job is to figure out the reason."
    },
    activity: {
      title: "Engineering scavenger hunt",
      time: "20 min",
      tools: ["Notebook", "Phone camera (optional)"],
      deliverable: "Scavenger hunt table",
      intro: "<p>Find engineered objects all around you and analyze them like an engineer.</p>",
      steps: [
        "Make a table with four columns: <b>Object</b>, <b>Problem it solves</b>, <b>Best feature</b>, <b>Branch (civil, mechanical or aerospace)</b>.",
        "Find <b>eight</b> engineered objects. At least two must be bigger than you (a building, a door, a car, a bridge).",
        "Fill in every column. If an object fits more than one branch, list both.",
        "Star your favorite object and write one improvement you'd make to it.",
        "Submit your table in Canvas."
      ],
      rubric: "<ul><li>8 objects, every column complete</li><li>At least two large objects</li><li>One improvement idea</li></ul>",
      extension: "Find an object you think is badly designed. Explain what problem it was supposed to solve and why it doesn't solve it well."
    },
    reflection: [
      "Which object on your list surprised you the most when you thought about how it was designed?",
      "Pick one feature from your list. What might happen if engineers had left it out?",
      "Why do you think engineers keep improving objects that already work?"
    ]
  },

  /* ------------------------------------------------------------------ */
  3: {
    duration: "45 min",
    objectives: [
      "List the six steps of the engineering design process in order",
      "Explain what happens at each step",
      "Explain why engineers repeat steps instead of stopping after the first try"
    ],
    reading: `
      <h3>A recipe for solving problems</h3>
      <p>Engineers don't just start building. They follow a set of steps called the <b>engineering design process</b>. In this course, we use six steps:</p>
      <ol>
        <li><b>Ask.</b> What is the problem? Who has it? What are the rules (how big, how much money, how much time)?</li>
        <li><b>Imagine.</b> Brainstorm lots of ideas. Wild ideas are welcome.</li>
        <li><b>Plan.</b> Pick the best idea. Sketch it and list the materials you'll need.</li>
        <li><b>Create.</b> Build it. This could be a model, a prototype or a 3D model in Tinkercad.</li>
        <li><b>Test.</b> Try it out. Does it solve the problem? Measure and write down what happens.</li>
        <li><b>Improve.</b> Use what you learned in testing to make it better.</li>
      </ol>
      <h3>Around and around</h3>
      <p>After <b>Improve</b>, you test again. Then improve again. The design process is a loop, not a line. Each trip around the loop is called an <b>iteration</b>. Most great designs take many iterations.</p>
      <div class="callout"><h4>Failure is data</h4><p>When a test fails, you haven't failed. You've learned something your design needs. The Wright brothers crashed many gliders before their first powered flight in 1903. Each crash told them what to fix.</p></div>
      <h3>Criteria and constraints</h3>
      <p>During <b>Ask</b>, engineers write down two kinds of rules. <b>Criteria</b> are what the design must do (<i>hold 10 books</i>). <b>Constraints</b> are limits (<i>use only 20 straws</i>). You'll use these words all semester.</p>`,
    vocab: [
      ["Engineering design process", "The steps engineers follow to solve problems: ask, imagine, plan, create, test, improve."],
      ["Brainstorm", "Coming up with many ideas quickly without judging them."],
      ["Prototype", "A first model of a design, built to test the idea."],
      ["Iteration", "One trip around the design loop. Designs improve with each iteration."]
    ],
    check: [
      { q: "You've just built your model. What's the next step?",
        options: ["Ask", "Test", "Imagine"], answer: 1, explain: "After Create comes Test." },
      { q: "\"The tower can use only 10 sheets of paper\" is a…",
        options: ["Criterion", "Constraint"], answer: 1, explain: "It's a limit, so it's a constraint." }
    ],
    walkthrough: {
      intro: "<p>Practice the six steps with a small problem: <b>your pencil keeps rolling off your desk.</b> Write each step in your notebook.</p>",
      steps: [
        { title: "Ask", body: "<p>Write the problem and the rules. Problem: <i>my pencil rolls off my desk.</i> Criterion: <i>pencil stays on the desk when the desk is bumped.</i> Constraint: <i>use only paper and tape.</i></p>" },
        { title: "Imagine", body: "<p>Write or sketch at least four ideas in 3 minutes: a paper tray, a tape flag on the pencil, a folded paper triangle the pencil sits in, a paper clip holder.</p>" },
        { title: "Plan", body: "<p>Circle your best idea. Sketch it and list materials: <i>1 sheet of paper, 2 pieces of tape.</i></p>" },
        { title: "Create", body: "<p>If you have paper and tape, build it now (5 minutes max). If not, describe how you would.</p>" },
        { title: "Test", body: "<p>Put the pencil in it and bump the desk gently three times. Did the pencil stay? Write the result.</p>" },
        { title: "Improve", body: "<p>Write one change that would make it better, such as making the walls taller. That change starts your next iteration.</p>" }
      ]
    },
    example: {
      title: "Put the steps in order",
      problem: "<p>A student is designing a bird feeder. Put these actions in design process order:</p><ol type=\"a\"><li>Fills it with seed and watches for a week. Squirrels eat all the seed.</li><li>Sketches five different feeder ideas.</li><li>Builds the feeder from a milk jug.</li><li>Finds out which birds live nearby and that the feeder must cost under $10.</li><li>Adds a cone to keep squirrels off.</li><li>Picks the milk jug idea and lists materials.</li></ol>",
      steps: [
        "<b>Ask:</b> (d) learn which birds live nearby and the $10 limit.",
        "<b>Imagine:</b> (b) sketch five ideas.",
        "<b>Plan:</b> (f) pick the milk jug idea and list materials.",
        "<b>Create:</b> (c) build the feeder.",
        "<b>Test:</b> (a) watch for a week and discover the squirrel problem.",
        "<b>Improve:</b> (e) add a cone to stop squirrels."
      ],
      answer: "d, b, f, c, a, e",
      takeaway: "Testing found a problem the student didn't think of. That's exactly what testing is for."
    },
    activity: {
      title: "Design process poster",
      time: "20 min",
      tools: ["Paper and markers, or Google Slides"],
      deliverable: "Design process poster",
      intro: "<p>Make a poster that teaches the design process to a younger student.</p>",
      steps: [
        "Draw the six steps as a circle or loop with arrows.",
        "Write a one-sentence explanation of each step in your own words.",
        "Pick an example problem (not the pencil or bird feeder) and add what happens at each step for that example.",
        "Add a small drawing or icon for each step.",
        "Submit a photo of your poster in Canvas."
      ],
      rubric: "<ul><li>All six steps in order, drawn as a loop</li><li>Clear explanations in your own words</li><li>An example for every step</li></ul>",
      extension: "Research one famous invention and find out how many prototypes or iterations it took."
    },
    reflection: [
      "Why is the design process drawn as a loop instead of a straight line?",
      "Which of the six steps do you think is the hardest, and why?",
      "Describe a time you tried something, it didn't work and you tried again in a better way."
    ]
  },

  /* ------------------------------------------------------------------ */
  4: {
    duration: "40 min",
    objectives: [
      "Explain why engineers keep notebooks",
      "Follow the basic notebook rules: date, label, never erase",
      "Set up your engineering notebook and write your first entry"
    ],
    reading: `
      <h3>Your engineering memory</h3>
      <p>Engineers write everything down in an <b>engineering notebook</b>: ideas, sketches, measurements, test results and even mistakes. Why? Because memory isn't reliable. A month from now, you won't remember exactly how tall your tower was or why you chose one idea over another. Your notebook will.</p>
      <p>Notebooks also help others. If a teammate is absent, they can read your notebook and catch up. If you invent something amazing, your notebook can prove you thought of it first.</p>
      <h3>The rules</h3>
      <ol>
        <li><b>Date every entry.</b> Write the date at the top each time you work.</li>
        <li><b>Give each entry a title,</b> like <i>Paper tower challenge</i>.</li>
        <li><b>Don't erase.</b> If you make a mistake, cross it out with one line. Mistakes show your thinking.</li>
        <li><b>Label your sketches.</b> Add arrows and words that point out parts.</li>
        <li><b>Use units.</b> Write <i>32 cm</i>, not just <i>32</i>.</li>
        <li><b>Write what you'll do next.</b> End each entry with a next step.</li>
      </ol>
      <h3>What goes in it this week</h3>
      <p>Your scavenger hunt table, your design process notes and your tower challenge plan, sketches and results all belong in your notebook.</p>`,
    vocab: [
      ["Engineering notebook", "A record of everything an engineer does on a project."],
      ["Entry", "One dated section of your notebook."],
      ["Label", "Words and arrows that name the parts of a sketch."],
      ["Unit", "What a number measures, like cm, kg or seconds."]
    ],
    check: [
      { q: "You wrote the wrong measurement. What should you do?",
        options: ["Erase it", "Cross it out with one line and write the right one", "Rip out the page"],
        answer: 1, explain: "Crossing out keeps a record of your thinking." },
      { q: "Which measurement is written correctly?",
        options: ["The tower was 45", "The tower was 45 cm tall"],
        answer: 1, explain: "Always include units." }
    ],
    walkthrough: {
      intro: "<p>Set up your notebook step by step.</p>",
      steps: [
        { title: "Make the cover page", body: "<p>Write your name, <i>Elements of Engineering</i>, <i>Mr. Marsh</i> and the school year. Decorate it if you like.</p>" },
        { title: "Make a table of contents", body: "<p>On the next page, make three columns: <b>Date</b>, <b>Title</b>, <b>Page</b>. If you're using paper, number the corners of your first 20 pages.</p>" },
        { title: "Write your first entry", body: "<p>Write today's date and the title <i>What is engineering?</i> In 3–4 sentences, explain what engineers do and name the three branches you'll study.</p>" },
        { title: "Add a labeled sketch", body: "<p>Sketch one object from your scavenger hunt. Add at least three labels with arrows pointing to its features.</p>" },
        { title: "Add a next step", body: "<p>End the entry with: <i>Next: paper tower challenge.</i> Then add this entry to your table of contents.</p>" }
      ]
    },
    example: {
      title: "Fix this notebook entry",
      problem: "<p>A student wrote: <i>Made a tower. It was 40. Fell over. Will fix.</i> What's missing, and how would you rewrite it?</p>",
      steps: [
        "Missing a <b>date and title</b>. Add: <i>Sept 5: Paper tower, test 1.</i>",
        "Missing <b>units</b>. Change \"40\" to <i>40 cm tall</i>.",
        "Missing <b>details</b>. Add how it was built: <i>3 rolled-paper tubes taped in a triangle.</i>",
        "Missing <b>why</b> it fell. Add: <i>It leaned because the base was too narrow.</i>",
        "Next step is too vague. Change to: <i>Next: make the base twice as wide.</i>"
      ],
      answer: "Sept 5: Paper tower, test 1. Built 3 rolled-paper tubes taped in a triangle, 40 cm tall. It leaned and fell because the base was too narrow. Next: make the base twice as wide.",
      takeaway: "A good entry tells someone else exactly what you did, what happened and what you'll do next."
    },
    activity: {
      title: "Notebook setup",
      time: "20 min",
      tools: ["Engineering notebook"],
      deliverable: "Photo of your notebook pages",
      intro: "<p>Get your notebook ready for the rest of the semester.</p>",
      steps: [
        "Finish the cover page and table of contents from the walkthrough.",
        "Add dated entries for Days 1, 2 and 3 of this week (introduction card, scavenger hunt, design process).",
        "Check each entry: date, title, labels, units, next step.",
        "Photograph your pages and submit in Canvas."
      ],
      rubric: "<ul><li>Cover and table of contents</li><li>Four dated entries with titles</li><li>At least one labeled sketch</li></ul>",
      extension: "Look up a page from Leonardo da Vinci's notebooks. What do you notice about how he recorded his ideas?"
    },
    reflection: [
      "Why is it important not to erase mistakes in your engineering notebook?",
      "How could your notebook help a teammate who missed class?",
      "Which notebook rule do you think will be hardest for you to remember?"
    ]
  },

  /* ------------------------------------------------------------------ */
  5: {
    duration: "50 min",
    objectives: [
      "Use all six steps of the design process to solve a challenge",
      "Test a design and record measurements in your notebook",
      "Improve a design based on test results"
    ],
    before: "<p>You'll need <b>10 sheets of paper</b>, <b>50 cm of tape</b>, scissors and a ruler or measuring tape. Working from home? Any printer or notebook paper works.</p>",
    reading: `
      <h3>The challenge</h3>
      <p>Build the <b>tallest free-standing tower</b> you can using only paper and tape. Your tower must stand on its own for <b>10 seconds</b> without anyone touching it.</p>
      <h3>Criteria and constraints</h3>
      <ul>
        <li><b>Criterion:</b> as tall as possible</li>
        <li><b>Criterion:</b> stands on its own for 10 seconds</li>
        <li><b>Constraint:</b> 10 sheets of paper, 50 cm of tape</li>
        <li><b>Constraint:</b> 25 minutes of build time</li>
        <li><b>Constraint:</b> can't be taped to the table, wall or ceiling</li>
      </ul>
      <h3>Engineering tips</h3>
      <p>These ideas come from real structures. You'll learn more about why they work in the civil engineering unit.</p>
      <ul>
        <li><b>Tubes are stronger than flat sheets.</b> A rolled sheet of paper can hold far more weight than a flat one.</li>
        <li><b>Triangles don't wobble.</b> Squares can squish sideways. Triangles keep their shape.</li>
        <li><b>A wide base is stable.</b> Most tall structures are wider at the bottom than the top.</li>
        <li><b>Keep the top light.</b> Weight high up makes a tower tip over.</li>
      </ul>`,
    vocab: [
      ["Free-standing", "Stands on its own without being attached to anything."],
      ["Stable", "Resists tipping over."],
      ["Base", "The bottom of a structure that rests on the ground."],
      ["Load", "Weight or force a structure has to hold up."]
    ],
    check: [
      { q: "Which shape keeps its form best when pushed from the side?",
        options: ["Square", "Triangle", "Circle"], answer: 1, explain: "Triangles can't change shape without a side changing length." },
      { q: "Why make the base of a tower wide?",
        options: ["It looks better", "It makes the tower more stable", "It uses less paper"], answer: 1,
        explain: "A wider base makes the tower harder to tip over." }
    ],
    walkthrough: {
      intro: "<p>Follow the design process for this challenge. Record each step in your notebook.</p>",
      steps: [
        { title: "Ask (3 min)", body: "<p>Write the challenge, the criteria and the constraints in your notebook.</p>" },
        { title: "Imagine (5 min)", body: "<p>Sketch at least three different tower ideas. Try one made of tubes, one using triangles and one with a wide base that narrows.</p>" },
        { title: "Plan (3 min)", body: "<p>Choose one idea. Sketch it with labels and estimate how many sheets each part will use.</p>" },
        { title: "Create (15 min)", body: "<p>Build your tower. Keep track of time. Save at least two sheets in case you need to fix something.</p>" },
        { title: "Test", body: "<p>Let go and count to 10. If it stands, measure from the table to the highest point in centimeters. Write the height in your notebook. If it falls, write down where and why it failed.</p>" },
        { title: "Improve", body: "<p>Use your leftover paper and the remaining time to make one improvement. Test and measure again. Record the new height.</p>" }
      ]
    },
    example: {
      title: "How much did the tower improve?",
      problem: "<p>A student's first tower was 62 cm tall. After widening the base and adding a triangle brace, it reached 85 cm. How much taller is it, and what's the percent improvement?</p>",
      steps: [
        "Find the difference: 85 cm − 62 cm = 23 cm taller.",
        "Divide the difference by the original height: 23 ÷ 62 ≈ 0.37.",
        "Multiply by 100 to get a percent: 0.37 × 100 = 37%."
      ],
      answer: "23 cm taller, about a 37% improvement.",
      takeaway: "Engineers measure their improvements with numbers so they can prove a change actually helped."
    },
    activity: {
      title: "Paper tower challenge",
      time: "30 min",
      tools: ["10 sheets of paper", "50 cm tape", "Scissors", "Ruler"],
      deliverable: "Tower photo and notebook entry",
      intro: "<p>Build, test and improve your tower. If you're working with a partner, each of you should record the results in your own notebook.</p>",
      steps: [
        "Complete the Ask, Imagine and Plan steps in your notebook.",
        "Build your tower in 15 minutes or less.",
        "Test it: it must stand for 10 seconds. Measure its height in centimeters.",
        "Take a photo of your tower next to a ruler or measuring tape.",
        "Make one improvement, retest and measure again.",
        "Calculate your improvement in centimeters and as a percent.",
        "Upload your photo and notebook entry to Canvas."
      ],
      rubric: "<ul><li>Notebook shows all six design process steps</li><li>Two measured heights with units</li><li>Improvement calculated</li><li>Photo included</li></ul>",
      extension: "Test how much weight your tower can hold. Stack coins or erasers on top one at a time until it fails. Record the number."
    },
    reflection: [
      "What was the most important design choice you made, and how did it affect your tower?",
      "What failed during testing, and what did you change because of it?",
      "If you did this challenge again with the same materials, what would you do differently from the start?"
    ]
  }
});
