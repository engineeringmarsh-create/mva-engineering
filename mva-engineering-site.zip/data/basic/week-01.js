/* Basic Engineering — Week 1: The engineering design process
   Lesson titles and focus statements come from course.js. */
MVA.registerWeek("basic", 1, {

  /* ------------------------------------------------------------------ */
  1: {
    duration: "45–50 min",
    objectives: [
      "Define engineering and explain how it differs from science",
      "Describe what civil, mechanical, electrical, aerospace, chemical and nuclear engineers do",
      "Identify which disciplines worked together to create an everyday product",
      "Explain how this course is organized and how to complete a lesson"
    ],
    before: "<p>You'll need a notebook (paper or digital) for this lesson. Keep it for the whole course.</p>",
    reading: `
      <h3>What is engineering?</h3>
      <p><b>Engineering</b> is using science, math and creativity to design solutions to problems people actually have. Scientists ask <i>why does the world work this way?</i> Engineers ask <i>how can we use what we know to make something that works?</i></p>
      <p>A physicist might study how electricity moves through a wire. An electrical engineer uses that knowledge to design a phone charger that is small, safe, cheap and charges in under an hour. That second part, working within limits like size, safety and cost, is what makes engineering engineering.</p>
      <h3>Engineers design under constraints</h3>
      <p>Every real problem comes with limits. Money, time, materials, safety rules, the laws of physics and what users will accept are all <b>constraints</b>. A bridge can't cost infinite money. A rocket can't weigh too much to lift off. Good engineering is finding the best solution that fits inside the constraints, not a perfect solution that ignores them.</p>
      <h3>The six disciplines in this course</h3>
      <p>Engineering has dozens of branches. This course covers six of the largest. You'll complete a major project in each one.</p>
      <ul>
        <li><b>Civil engineering:</b> the built environment, including bridges, buildings, roads, dams, water systems and airports.</li>
        <li><b>Mechanical engineering:</b> anything that moves or uses energy, including engines, robots, HVAC systems, prosthetics and consumer products.</li>
        <li><b>Electrical engineering:</b> circuits, electronics, power grids, sensors, communications and the hardware inside computers.</li>
        <li><b>Aerospace engineering:</b> aircraft, rockets, satellites and drones, anything that flies in the atmosphere or in space.</li>
        <li><b>Chemical engineering:</b> turning raw materials into useful products at large scale, including fuels, medicines, plastics, food and clean water.</li>
        <li><b>Nuclear engineering:</b> using energy and radiation from the nucleus of the atom for power plants, medical imaging and cancer treatment.</li>
      </ul>
      <h3>Disciplines work together</h3>
      <p>Almost nothing is designed by one type of engineer. An electric car needs mechanical engineers for the drivetrain and suspension, electrical engineers for the battery and motor controller, chemical engineers for the battery cells, aerospace-style engineers for aerodynamics, and civil engineers for the roads and charging stations it runs on.</p>
      <h3>How this course works</h3>
      <p>The course has 18 weeks with 5 lessons each. Weeks 1–3 teach the design process, technical drawing and CAD. Then you'll spend two weeks on each discipline: one week learning the ideas and one week on a major project. The last three weeks are a final challenge where you pick a discipline and solve a problem of your choice.</p>
      <p>Every lesson has the same seven sections. Finish all of them and you'll get a verification code to submit in Canvas.</p>`,
    vocab: [
      ["Engineering", "Applying science, math and creativity to design solutions to real problems."],
      ["Constraint", "A limit a design must stay within, such as cost, size, time or safety rules."],
      ["Discipline", "A branch of engineering focused on a type of problem, such as civil or electrical."],
      ["Interdisciplinary", "Involving more than one discipline working together."]
    ],
    check: [
      { q: "Which question is most typical of an engineer rather than a scientist?",
        options: ["Why do metals expand when heated?", "How can we design a bridge joint that handles summer heat expansion?", "What is the boiling point of water at high altitude?"],
        answer: 1, explain: "Engineers apply knowledge to design something that works within constraints." },
      { q: "Designing a water treatment plant that removes contaminants at large scale is mainly which discipline?",
        options: ["Chemical engineering", "Aerospace engineering", "Nuclear engineering"],
        answer: 0, explain: "Chemical engineers design large-scale processes that transform or purify materials. Civil engineers often work on the pipes and structures too." }
    ],
    walkthrough: {
      intro: "<p>You'll practice spotting the disciplines behind a product by analyzing a smartphone together. Have your notebook open and make a two-column table: <b>Part or system</b> and <b>Discipline</b>.</p>",
      steps: [
        { title: "List the systems", body: "<p>Write down every major part or system of a smartphone you can think of. Aim for at least six. For example: battery, screen, case, camera, antenna, processor, speaker, charging port.</p>" },
        { title: "Match each system to a discipline", body: "<p>Beside each item, write the discipline most responsible for it. The <b>case</b> and <b>buttons</b> are mechanical (fit, strength, drop protection). The <b>processor</b>, <b>antenna</b> and <b>charging circuit</b> are electrical. The <b>battery chemistry</b> and <b>screen glass</b> involve chemical engineers.</p>" },
        { title: "Look beyond the device", body: "<p>Add the systems the phone depends on but doesn't contain: cell towers (civil and electrical), satellites for GPS (aerospace), the power plant that charges it (could be nuclear, chemical or electrical), and the factory that builds it (mechanical and chemical).</p>" },
        { title: "Count and conclude", body: "<p>Count how many of the six disciplines appear in your table. Most students find all six. Write one sentence in your notebook explaining what this tells you about how engineers work.</p>" }
      ]
    },
    example: {
      title: "Which disciplines are needed to design a new airport terminal?",
      problem: "<p>A city wants a new airport terminal with jet bridges, a baggage system, solar panels on the roof and its own backup power. Identify at least four disciplines and what each would design.</p>",
      steps: [
        "<b>Civil:</b> the building structure and foundation, the runway and taxiway pavement, drainage and water supply.",
        "<b>Mechanical:</b> the moving jet bridges, the baggage conveyor system, escalators, and heating and air conditioning.",
        "<b>Electrical:</b> the solar panel system, the building's power distribution, lighting and backup generators.",
        "<b>Aerospace:</b> making sure gate spacing and jet bridge heights fit each aircraft type, and the airfield layout for safe taxiing.",
        "<b>Chemical:</b> fuel storage and handling for the aircraft, and de-icing fluid systems."
      ],
      answer: "At least five disciplines are needed: civil, mechanical, electrical, aerospace and chemical. Large projects are almost always interdisciplinary.",
      takeaway: "When you analyze any big project, break it into systems first, then ask which discipline owns each system."
    },
    activity: {
      title: "Discipline scavenger hunt",
      time: "20 min",
      tools: ["Notebook", "Your surroundings"],
      deliverable: "Photo of your notebook table",
      intro: "<p>Find engineered objects around you, at school or at home, and connect each one to the disciplines that designed it.</p>",
      steps: [
        "Find <b>six</b> different engineered objects or systems around you. At least one must be bigger than a car (a building, road, power line and so on).",
        "Make a table in your notebook with columns: <b>Object</b>, <b>Problem it solves</b>, <b>Disciplines involved</b>, <b>One constraint the engineers faced</b>.",
        "Fill in all four columns for each object. Name at least two disciplines for each.",
        "Circle the object you think required the most disciplines and write two sentences explaining why.",
        "Photograph your table and upload it to the Canvas assignment."
      ],
      rubric: "<ul><li>6 objects with all four columns complete</li><li>Disciplines match the systems accurately</li><li>Constraints are specific (\"must cost under $50\", not \"money\")</li></ul>",
      extension: "Look up one of the six disciplines in the Occupational Outlook Handbook (linked in the Resource library). Write down its median pay, typical degree and expected job growth."
    },
    reflection: [
      "In your own words, what is the difference between a scientist and an engineer?",
      "Which of the six disciplines sounds most interesting to you right now, and why?",
      "Think of a problem in your school or neighborhood. Which discipline would be best suited to solve it?"
    ],
    resources: [
      { label: "Occupational Outlook Handbook: Engineering", url: "https://www.bls.gov/ooh/architecture-and-engineering/home.htm" },
      { label: "TryEngineering: explore engineering fields", url: "https://tryengineering.org" }
    ]
  },

  /* ------------------------------------------------------------------ */
  2: {
    duration: "50 min",
    objectives: [
      "List the eight steps of the engineering design process in order",
      "Explain why the design process is a loop, not a straight line",
      "Identify which step an engineer is on from a description of their work",
      "Apply the design process to plan a solution to a simple problem"
    ],
    reading: `
      <h3>Why engineers use a process</h3>
      <p>When faced with a problem, most people jump straight to building the first idea that comes to mind. Sometimes that works. Often, it means solving the wrong problem, missing a better idea or discovering a fatal flaw after spending time and money. The <b>engineering design process</b> is a set of steps that helps engineers avoid those mistakes.</p>
      <h3>The eight steps</h3>
      <ol>
        <li><b>Define the problem.</b> Describe the need clearly: who has it, why it matters, and what a successful solution must do.</li>
        <li><b>Research.</b> Learn about the users, the science involved and existing solutions. Don't reinvent something that already exists.</li>
        <li><b>Specify requirements.</b> Turn the goal into measurable <b>criteria</b> (what the design must do) and <b>constraints</b> (limits it must stay within).</li>
        <li><b>Brainstorm solutions.</b> Generate many ideas. Quantity first, judgment later.</li>
        <li><b>Select the best solution.</b> Compare ideas against the requirements. A decision matrix (Day 4) makes this objective.</li>
        <li><b>Develop and prototype.</b> Build a model, CAD file, simulation or physical prototype of the chosen solution.</li>
        <li><b>Test and evaluate.</b> Measure how well the prototype meets each requirement. Collect real data.</li>
        <li><b>Iterate and communicate.</b> Use test results to improve the design, then share the final solution with drawings, reports and presentations.</li>
      </ol>
      <h3>It's a loop</h3>
      <p>The process isn't a straight line. Testing almost always reveals problems, and that sends you back to an earlier step. A failed test might mean redesigning a part (back to step 6), choosing a different idea (step 5) or realizing you misunderstood the problem (step 1). Going back isn't failure. It's <b>iteration</b>, and it's how good designs become great designs.</p>
      <div class="callout"><h4>Real example</h4><p>James Dyson built 5,127 prototypes of his bagless vacuum cleaner over five years before he had one that worked well enough to sell. Each prototype was one trip around the loop.</p></div>
      <h3>Other versions</h3>
      <p>You'll see the design process drawn with 5, 6, 8 or even 12 steps. NASA, IDEO and PLTW all use slightly different versions. They all share the same core idea: understand the problem, generate options, choose, build, test and improve.</p>`,
    vocab: [
      ["Engineering design process", "A repeatable series of steps engineers use to solve problems."],
      ["Criteria", "Requirements a design must meet to be successful (what it must do)."],
      ["Prototype", "An early model of a design built to test ideas."],
      ["Iteration", "Repeating steps of the process to improve a design."]
    ],
    check: [
      { q: "An engineer is interviewing nurses about problems with hospital beds. Which step is this?",
        options: ["Brainstorm", "Research", "Test and evaluate"],
        answer: 1, explain: "Learning about users and their needs is research. It may also help define the problem." },
      { q: "A prototype fails its drop test. What should happen next?",
        options: ["The project is cancelled", "Return to an earlier step and improve the design", "Skip to communicating results"],
        answer: 1, explain: "Failed tests feed back into the loop. That is iteration." }
    ],
    walkthrough: {
      intro: "<p>Walk through all eight steps with a simple problem: <b>students' water bottles keep falling off their desks.</b> Write each step's heading in your notebook and fill it in as you go.</p>",
      steps: [
        { title: "Define the problem", body: "<p>Write a one-sentence problem: <i>Students need a way to keep water bottles from falling off narrow classroom desks, because spills damage laptops and interrupt class.</i> Notice it describes the need, not a solution.</p>" },
        { title: "Research", body: "<p>List three things you'd want to know: How wide are the desks? What sizes are students' bottles? Do any products already exist, like cup holders for desks? Spend two minutes searching online for \"desk cup holder\" and note one existing product.</p>" },
        { title: "Specify requirements", body: "<p>Write two criteria and two constraints. Criteria: <i>holds bottles 6.5–9 cm in diameter; keeps the bottle upright when the desk is bumped.</i> Constraints: <i>costs under $5 to make; attaches without tools or damage to the desk.</i></p>" },
        { title: "Brainstorm", body: "<p>Sketch at least four quick ideas in 4 minutes: a clip-on ring, a weighted base, a hook under the desk, a magnetic sleeve. Don't judge them yet.</p>" },
        { title: "Select", body: "<p>Circle the idea that best meets all four requirements and write one sentence explaining why. (On Day 4 you'll learn to do this with a decision matrix.)</p>" },
        { title: "Prototype, test, iterate, communicate", body: "<p>Describe how you'd finish: model the clip in Tinkercad and 3D print it, test it with five different bottles and a desk bump, adjust the ring size based on results, then present a sketch and the test data. Write these as four short bullets.</p>" }
      ]
    },
    example: {
      title: "Name the step",
      problem: "<p>Read each description and identify the design process step:</p><ol type=\"a\"><li>A team writes \"The drone must carry 500 g for at least 10 minutes and cost less than $200.\"</li><li>An engineer runs a car seat through 30 crash simulations and records the forces.</li><li>After the tests, the team thickens one bracket and runs the simulation again.</li><li>Students list 25 possible ways to reduce cafeteria waste in 10 minutes.</li></ol>",
      steps: [
        "(a) Measurable requirements with a limit on cost: <b>Specify requirements</b> (step 3).",
        "(b) Running tests and recording data: <b>Test and evaluate</b> (step 7).",
        "(c) Changing the design based on test results: <b>Iterate</b> (step 8, looping back to step 6).",
        "(d) Generating many ideas quickly without judging: <b>Brainstorm</b> (step 4)."
      ],
      answer: "a: Specify requirements, b: Test and evaluate, c: Iterate, d: Brainstorm.",
      takeaway: "Look for the action word. Measurable limits mean specifying. Recording data means testing. Changing after a test means iterating."
    },
    activity: {
      title: "Design process map",
      time: "20 min",
      tools: ["Notebook or Google Slides", "Internet"],
      deliverable: "Design process map (photo or slide)",
      intro: "<p>Choose a product that has changed a lot over time (phones, sneakers, bikes, video game controllers, cars). Show how its engineers moved around the design process loop.</p>",
      steps: [
        "Pick your product and find at least two earlier versions of it online.",
        "Draw the eight-step design process as a loop on one page or slide.",
        "For each step, write one example of what the engineers of your product probably did at that step.",
        "Draw an arrow showing one iteration: what problem did testing or user feedback reveal, and how did the next version fix it?",
        "Upload a photo or the slide to Canvas."
      ],
      rubric: "<ul><li>All eight steps shown in the correct order as a loop</li><li>Each step has a realistic, product-specific example</li><li>At least one clear iteration, with the problem and the fix</li></ul>",
      extension: "Research the design process used by NASA or IDEO. Compare it to the eight-step version. What does it add or combine?"
    },
    reflection: [
      "Why do you think engineers research before brainstorming instead of after?",
      "Describe a time you iterated on something (a project, a skill, a game strategy). What did you change after the first attempt?",
      "Which step of the design process do you think is most often skipped, and what goes wrong when it is?"
    ],
    resources: [
      { label: "Design process reference sheet", url: "resources.html#design-process" }
    ]
  },

  /* ------------------------------------------------------------------ */
  3: {
    duration: "50 min",
    objectives: [
      "Write a problem statement that describes a need without naming a solution",
      "Distinguish criteria from constraints",
      "Write measurable criteria and constraints",
      "Assemble a complete design brief"
    ],
    reading: `
      <h3>The most important step</h3>
      <p>Albert Einstein supposedly said that if he had an hour to solve a problem, he'd spend 55 minutes understanding the problem. Engineers take this seriously. A brilliant solution to the wrong problem is worthless. Defining the problem well is the step that makes every later step easier.</p>
      <h3>Problem statements</h3>
      <p>A good <b>problem statement</b> answers three questions: <i>Who</i> has the problem? <i>What</i> is the need? <i>Why</i> does it matter? Most importantly, it does <b>not</b> name a solution.</p>
      <ul>
        <li>Weak: <i>We need to build an app that reminds students about homework.</i> (This names a solution, an app.)</li>
        <li>Strong: <i>Ninth-grade students frequently miss homework deadlines because assignments are posted in several places, which lowers their grades and increases stress.</i></li>
      </ul>
      <p>The strong version leaves room for many solutions: a single calendar, a new posting policy, a paper planner, or yes, an app.</p>
      <h3>Criteria and constraints</h3>
      <p><b>Criteria</b> describe what the design must <i>do</i> or how well it must perform. <b>Constraints</b> are limits the design must <i>stay within</i>. Together, they're called <b>requirements</b> or <b>specifications</b>.</p>
      <ul>
        <li>Criterion: <i>The bridge must support a 12,000 kg truck.</i></li>
        <li>Constraint: <i>The bridge must cost less than $400,000 and span the 40 m river without supports in the water.</i></li>
      </ul>
      <h3>Make them measurable</h3>
      <p>\"Strong,\" \"cheap,\" \"lightweight\" and \"easy to use\" can't be tested. Every requirement should include a number and a unit, or a clear pass/fail test, so you can prove whether your design meets it.</p>
      <ul>
        <li>Not measurable: <i>The backpack should be light.</i></li>
        <li>Measurable: <i>The empty backpack must weigh less than 0.9 kg.</i></li>
      </ul>
      <h3>The design brief</h3>
      <p>A <b>design brief</b> collects everything on one page: client, problem statement, design statement (what you'll design, in general terms), criteria and constraints. It's the contract between the engineer and the client. When people disagree later about what the design should do, the brief settles it.</p>`,
    vocab: [
      ["Problem statement", "A clear description of who has a need, what it is and why it matters, without naming a solution."],
      ["Criteria", "What a successful design must do or how well it must perform."],
      ["Constraint", "A limit the design must stay within, like budget, size, time or materials."],
      ["Design brief", "A one-page document listing the client, problem, criteria and constraints for a project."]
    ],
    check: [
      { q: "\"The lunchbox must keep food below 5 °C for 4 hours.\" This is a…",
        options: ["Criterion", "Constraint", "Problem statement"],
        answer: 0, explain: "It describes how well the design must perform." },
      { q: "Which requirement is measurable?",
        options: ["The chair should be comfortable", "The chair must support 135 kg", "The chair should look modern"],
        answer: 1, explain: "It has a number and a unit you can test." }
    ],
    walkthrough: {
      intro: "<p>Build a design brief together for this situation: <b>the school's robotics team carries heavy toolboxes between the lab and competition fields, and students keep hurting their backs.</b></p>",
      steps: [
        { title: "Identify the client and users", body: "<p>Client: the robotics team coach. Users: team members aged 14–18. Write both in your notebook.</p>" },
        { title: "Write the problem statement", body: "<p>Answer who, what and why without a solution: <i>Robotics team members need to move 15–25 kg of tools between the lab and competition fields, because carrying toolboxes by hand causes strain and slows setup.</i></p>" },
        { title: "Write a design statement", body: "<p>Describe what you'll design in general terms: <i>Design a device or system that lets one student safely move the team's tools between locations.</i></p>" },
        { title: "List criteria", body: "<p>Write at least three, all measurable: <i>carries at least 25 kg; can be moved by one student with less than 100 N of push force; protects tools from falling out when tilted 30°.</i></p>" },
        { title: "List constraints", body: "<p>Write at least three: <i>costs less than $150; fits through a 0.8 m doorway; weighs less than 12 kg empty; ready in 4 weeks.</i></p>" },
        { title: "Check your brief", body: "<p>Reread every requirement. Does each have a number or a clear pass/fail test? Does the problem statement avoid naming a solution like \"a cart\"? Fix any that don't.</p>" }
      ]
    },
    example: {
      title: "Fix this design brief",
      problem: "<p>A student wrote: <i>Problem: We need a solar phone charger for the courtyard. Criteria: It should charge fast and be durable. Constraints: Not too expensive.</i> Rewrite it correctly.</p>",
      steps: [
        "The problem names a solution (\"solar phone charger\"). Rewrite to describe the need: <i>Students who eat lunch in the courtyard have no way to charge phones there, so many leave lunch early or run out of battery before afternoon classes.</i>",
        "\"Charge fast\" isn't measurable. Rewrite: <i>adds at least 20% battery to a typical phone in 30 minutes.</i>",
        "\"Durable\" isn't measurable. Rewrite: <i>works after 2 years outdoors in Florida weather; survives being bumped by a 10 kg backpack.</i>",
        "\"Not too expensive\" isn't measurable. Rewrite: <i>total cost under $300, including installation.</i> Add another constraint: <i>must not require digging or new wiring.</i>"
      ],
      answer: "A good brief has a solution-free problem statement and requirements that each include a number, a unit or a pass/fail test.",
      takeaway: "When you read a requirement, ask: how would I test this? If you can't answer, it isn't finished."
    },
    activity: {
      title: "Write a design brief",
      time: "25 min",
      tools: ["Design brief template (notebook or doc)"],
      deliverable: "Completed design brief",
      intro: "<p>Pick a real problem from your own life or school and write a complete design brief for it. You don't have to solve it.</p>",
      steps: [
        "Choose a problem you've personally experienced. Examples: a crowded hallway, a backpack that's always too heavy, a pet that escapes the yard.",
        "Identify the client and the users.",
        "Write a problem statement that answers who, what and why, without naming a solution.",
        "Write a one-sentence design statement.",
        "Write at least three measurable criteria and three measurable constraints.",
        "Trade briefs with a classmate (or reread yours tomorrow) and check that every requirement is testable. Revise.",
        "Submit the final brief in Canvas."
      ],
      rubric: "<ul><li>Problem statement covers who, what and why with no solution named</li><li>3+ criteria and 3+ constraints, correctly labeled</li><li>Every requirement is measurable or pass/fail</li></ul>",
      extension: "Rank your criteria from most to least important. You'll use this ranking for weights in tomorrow's decision matrix."
    },
    reflection: [
      "Why is it a problem when a problem statement names a solution?",
      "Explain the difference between a criterion and a constraint using an example of your own.",
      "Which requirement in your design brief was hardest to make measurable, and how did you do it?"
    ]
  },

  /* ------------------------------------------------------------------ */
  4: {
    duration: "50 min",
    objectives: [
      "Explain why engineers use decision matrices",
      "Assign weights to criteria based on importance",
      "Score options and calculate weighted totals",
      "Interpret a decision matrix result and justify a choice"
    ],
    reading: `
      <h3>Choosing between good ideas</h3>
      <p>After brainstorming, you'll often have several ideas that could work. Picking a favorite by gut feeling is risky. You might be biased toward your own idea, or the most exciting one, even if it doesn't fit the requirements best. A <b>decision matrix</b> makes the choice objective and shows others how you decided.</p>
      <h3>How a weighted decision matrix works</h3>
      <ol>
        <li><b>List the options</b> as columns.</li>
        <li><b>List the criteria</b> as rows. Use the requirements from your design brief.</li>
        <li><b>Assign a weight</b> to each criterion to show how important it is. A common scale is 1 (nice to have) to 5 (essential). Some teams use percentages that add up to 100%.</li>
        <li><b>Score each option</b> on each criterion. A common scale is 1 (poor) to 5 (excellent). Score honestly using evidence, not hope.</li>
        <li><b>Multiply</b> each score by the criterion's weight.</li>
        <li><b>Add</b> the weighted scores for each option. The highest total is the strongest option on paper.</li>
      </ol>
      <h3>Reading the result</h3>
      <p>The matrix doesn't make the decision for you. It organizes your thinking. If two totals are very close, the options are basically tied, and you may need more research or a quick prototype. If an option fails a hard constraint (it's over budget, say), it's out no matter how high it scores.</p>
      <div class="callout"><h4>Watch for this</h4><p>If the result surprises you, check your weights. Often a surprising result means you weighted something higher or lower than you really believe. Adjusting weights after seeing the answer just to get your favorite to win defeats the purpose.</p></div>`,
    vocab: [
      ["Decision matrix", "A table that compares options against weighted criteria to choose the best one."],
      ["Weight", "A number showing how important a criterion is relative to the others."],
      ["Score", "How well an option meets a criterion, on a fixed scale."],
      ["Weighted score", "Score multiplied by weight."]
    ],
    check: [
      { q: "An option scores 4 on a criterion with a weight of 3. What's its weighted score?",
        options: ["7", "12", "1.33"], answer: 1, explain: "4 × 3 = 12." },
      { q: "Option A totals 62 but costs $40 over the hard budget limit. Option B totals 58 and is under budget. Which should you choose?",
        options: ["A, because it scored higher", "B, because A fails a constraint"], answer: 1,
        explain: "Hard constraints are pass/fail. An option that breaks one is eliminated." }
    ],
    walkthrough: {
      intro: "<p>Build a decision matrix to choose a design for the robotics team tool carrier from yesterday's walkthrough. The options are a <b>wheeled cart</b>, a <b>backpack frame</b> and a <b>rolling toolbox with a telescoping handle</b>. Draw the table in your notebook or a spreadsheet.</p>",
      steps: [
        { title: "Set up the table", body: "<p>Make columns: Criterion, Weight, Cart, Backpack, Rolling toolbox. Make rows: Capacity, Ease of moving, Protects tools, Cost, Fits through doors.</p>" },
        { title: "Assign weights (1–5)", body: "<p>Capacity 5, Ease of moving 4, Protects tools 3, Cost 3, Fits through doors 2. Ask: would the team accept a design that fails this? If not, give it a high weight.</p>" },
        { title: "Score each option (1–5)", body: "<p>Cart: 5, 4, 2, 4, 3. Backpack: 2, 2, 4, 3, 5. Rolling toolbox: 4, 4, 5, 3, 4. Write a short reason beside any score you aren't sure about.</p>" },
        { title: "Multiply and total", body: "<p>Cart: 25 + 16 + 6 + 12 + 6 = <b>65</b>. Backpack: 10 + 8 + 12 + 9 + 10 = <b>49</b>. Rolling toolbox: 20 + 16 + 15 + 9 + 8 = <b>68</b>.</p>" },
        { title: "Interpret", body: "<p>The rolling toolbox wins (68), but the cart is close (65). That's nearly a tie. A good engineer would note this and might build quick prototypes of both. Write one sentence stating your choice and why.</p>" }
      ]
    },
    example: {
      title: "Choose a material for a canoe paddle",
      problem: "<p>Options: <b>aluminum</b>, <b>wood</b> and <b>carbon fiber</b>. Criteria and weights: Light weight (5), Strength (4), Cost (3), Looks (1). Scores (1–5): Aluminum 3, 4, 4, 2. Wood 3, 3, 4, 5. Carbon fiber 5, 5, 1, 4. Calculate the totals and choose.</p>",
      steps: [
        "Aluminum: (3×5) + (4×4) + (4×3) + (2×1) = 15 + 16 + 12 + 2 = 45",
        "Wood: (3×5) + (3×4) + (4×3) + (5×1) = 15 + 12 + 12 + 5 = 44",
        "Carbon fiber: (5×5) + (5×4) + (1×3) + (4×1) = 25 + 20 + 3 + 4 = 52",
        "Carbon fiber is highest. But check constraints: if the brief has a hard budget limit that carbon fiber exceeds, it's eliminated, and aluminum (45) narrowly beats wood (44)."
      ],
      answer: "Carbon fiber wins with 52, as long as it meets the budget constraint. If it doesn't, choose aluminum (45).",
      takeaway: "Always calculate totals, then check every option against the hard constraints before deciding."
    },
    activity: {
      title: "Decide with a matrix",
      time: "25 min",
      tools: ["Google Sheets or notebook"],
      deliverable: "Completed decision matrix and justification",
      intro: "<p>Use the design brief you wrote yesterday. If you didn't finish it, use the courtyard phone-charging problem from yesterday's worked example.</p>",
      steps: [
        "Brainstorm and sketch at least three different solutions to your problem.",
        "Build a decision matrix with your criteria (at least four) as rows and your three solutions as columns.",
        "Assign a weight to each criterion and write a one-line reason for each weight.",
        "Score each solution on each criterion, then calculate weighted scores and totals. In a spreadsheet, use formulas like =B2*C2 and =SUM().",
        "Check each solution against your hard constraints and eliminate any that fail.",
        "Write a short paragraph naming your choice and explaining what the matrix showed.",
        "Submit the matrix and paragraph in Canvas."
      ],
      rubric: "<ul><li>3+ options and 4+ criteria</li><li>Weights justified</li><li>Calculations correct</li><li>Choice justified with evidence from the matrix</li></ul>",
      extension: "Change one weight by 2 points and recalculate. Does the winner change? If it does, your decision is sensitive to that weight. Note this in your paragraph."
    },
    reflection: [
      "What's one advantage of a decision matrix over simply voting on your favorite idea?",
      "How did you decide which criterion deserved the highest weight?",
      "Describe a situation outside engineering where a decision matrix would help you, such as choosing a college, a phone or a sport."
    ]
  },

  /* ------------------------------------------------------------------ */
  5: {
    duration: "45 min",
    objectives: [
      "Explain why engineers document their work",
      "Follow the rules for a professional engineering notebook",
      "Write a complete, dated notebook entry with sketches, data and decisions",
      "Set up your notebook for the rest of the course"
    ],
    reading: `
      <h3>If it isn't written down, it didn't happen</h3>
      <p>Engineering teams change, projects last years and designs get questioned in court. An <b>engineering notebook</b> is the permanent record of what you did, when you did it and why. It lets teammates continue your work, helps you remember why you made a decision months ago and can even prove who invented something first.</p>
      <h3>What goes in a notebook</h3>
      <ul>
        <li>Problem definitions, design briefs and research notes</li>
        <li>Brainstorm sketches, including ideas you rejected</li>
        <li>Calculations, with units at every step</li>
        <li>Decision matrices and the reasoning behind decisions</li>
        <li>Test procedures, raw data and observations</li>
        <li>Failures and what you learned from them</li>
        <li>Meeting notes and to-do lists</li>
      </ul>
      <h3>The rules</h3>
      <ol>
        <li><b>Date every entry.</b> Start each day's work with the date and a title.</li>
        <li><b>Write in ink or a locked digital format.</b> A notebook should show its history, not hide it.</li>
        <li><b>Never erase or remove pages.</b> Cross out mistakes with a single line so they stay readable. Wrong ideas are useful history.</li>
        <li><b>Label everything.</b> Sketches get titles and labels. Numbers get units. Graphs get axis labels and titles.</li>
        <li><b>Write for a stranger.</b> Someone who wasn't there should be able to understand and repeat your work.</li>
        <li><b>Record as you go.</b> Write notes during the work, not from memory at the end of the day.</li>
      </ol>
      <h3>Paper or digital</h3>
      <p>Your teacher will tell you which format to use. Paper notebooks are bound with numbered pages. Digital notebooks (Google Docs or OneNote, for example) should have a dated heading for each entry and keep their version history on. Either way, the rules are the same.</p>`,
    vocab: [
      ["Engineering notebook", "A permanent, dated record of an engineer's work, ideas, data and decisions."],
      ["Entry", "One dated section of a notebook describing a work session."],
      ["Raw data", "Measurements exactly as recorded, before any calculations."],
      ["Reproducible", "Documented well enough that someone else could repeat it and get the same results."]
    ],
    check: [
      { q: "You made a calculation mistake in your notebook. What should you do?",
        options: ["Erase it neatly", "Tear out the page", "Cross it out with one line and write the correction"],
        answer: 2, explain: "Mistakes stay readable so the record is complete and honest." },
      { q: "Which entry follows the rules best?",
        options: ["\"Tested it. Worked OK.\"", "\"9/14: Drop test 3 of 5 from 1.2 m. Corner cracked on impact. Next: add 2 mm fillet to corners.\""],
        answer: 1, explain: "It's dated, specific, has units and records the next decision." }
    ],
    walkthrough: {
      intro: "<p>Set up your engineering notebook for this course and write your first complete entry.</p>",
      steps: [
        { title: "Create the cover and owner page", body: "<p>Write your name, course (Basic Engineering), teacher and school year on the cover or first page. Paper: number the first 20 pages in the top outside corner. Digital: create a document titled <i>Your Name: BE Engineering Notebook</i>.</p>" },
        { title: "Build a table of contents", body: "<p>Reserve the next page (or the top of your doc) for a table of contents with columns: <b>Date</b>, <b>Entry title</b>, <b>Page</b>. Add each entry as you go.</p>" },
        { title: "Start today's entry", body: "<p>Write today's date and the title <i>Week 1 summary</i>. Add it to your table of contents.</p>" },
        { title: "Summarize the week", body: "<p>In bullet points, record: the six disciplines, the eight design process steps, one example of a criterion and constraint, and how a decision matrix works. Use your own words.</p>" },
        { title: "Add a labeled sketch", body: "<p>Draw the design process as a loop with all eight steps labeled. Give it a title: <i>Figure 1: The engineering design process.</i></p>" },
        { title: "Close the entry", body: "<p>End with a <b>Next steps</b> line: what will you work on next? For example: <i>Next: practice isometric sketching (Week 2).</i></p>" }
      ]
    },
    example: {
      title: "Improve a weak notebook entry",
      problem: "<p>A student wrote: <i>Worked on the bridge. Tried a new design. It held more. Gonna try triangles next.</i> Rewrite this as a professional notebook entry.</p>",
      steps: [
        "Add the date and a title: <i>10/03: Bridge simulator, design iteration 2.</i>",
        "Make the work specific: <i>Changed the deck from a Pratt truss to a Warren truss and replaced 4 solid members with hollow tubes.</i>",
        "Record data with units: <i>Iteration 1 failed at a 180 kN load and cost $412,000. Iteration 2 passed the 225 kN test load and cost $389,500.</i>",
        "Explain the result: <i>The Warren truss spread the load more evenly, so fewer members were overloaded, and hollow tubes cut cost.</i>",
        "State the next step: <i>Next: reduce the top chord member size to cut cost while keeping a passing result.</i>"
      ],
      answer: "A professional entry has a date, a title, specific actions, data with units, an explanation and next steps.",
      takeaway: "Ask yourself: could a classmate who missed today repeat my work from this entry alone?"
    },
    activity: {
      title: "Notebook setup and audit",
      time: "20 min",
      tools: ["Engineering notebook"],
      deliverable: "Photos or link to your notebook",
      intro: "<p>Finish setting up your notebook and add entries for each lesson this week.</p>",
      steps: [
        "Complete the cover page, page numbers (paper) and table of contents from the walkthrough.",
        "Add a dated entry for each lesson this week (Days 1–4). Paste or redraw your scavenger hunt table, design process map, design brief and decision matrix.",
        "Check every entry against the six rules. Fix missing dates, labels and units.",
        "Add your Week 1 summary entry from the walkthrough.",
        "Photograph the pages or share a view-only link, and submit in Canvas."
      ],
      rubric: "<ul><li>Cover, table of contents and page numbers complete</li><li>Five dated entries for Week 1</li><li>Sketches labeled, numbers with units, mistakes crossed out, not erased</li></ul>",
      extension: "Look up the story of the Alexander Graham Bell and Elisha Gray telephone patent dispute. Write a short entry about how notebooks and filing dates mattered."
    },
    reflection: [
      "Why should mistakes be crossed out instead of erased in an engineering notebook?",
      "Describe a situation where a teammate would need to rely on your notebook.",
      "What's one notebook habit you need to work on, and how will you build it?"
    ]
  }
});
