/* Basic Engineering — course map (18 weeks x 5 lessons)
   Each lesson entry is [title, focus]. Full lesson content lives in week-XX.js.
   When you finish writing a week file, add its number to publishedWeeks. */
MVA.registerCourse({
  id: "basic",
  code: "BE",
  title: "Basic Engineering",
  level: "Survey",
  audience: "Algebra 1 recommended",
  tagline: "Six disciplines, six major projects, one final challenge you design yourself.",
  description:
    "A survey of the major branches of engineering. After learning the engineering design process and core CAD skills, you'll complete a major virtual project in civil, mechanical, electrical, aerospace, chemical and nuclear engineering using Tinkercad, Tinkercad Circuits, Onshape, OpenRocket and online simulations. The course ends with a final challenge where you pick a discipline and design your own solution to a real-world problem.",
  disciplines: ["Civil", "Mechanical", "Electrical", "Aerospace", "Chemical", "Nuclear"],
  tools: ["Tinkercad", "Tinkercad Circuits", "Onshape", "OpenRocket", "PhET simulations", "Bridge simulator"],
  outcomes: [
    "Apply the engineering design process and decision matrices to open-ended problems",
    "Communicate designs with sketches, orthographic drawings and dimensioned CAD models",
    "Use core equations from statics, mechanics, circuits, flight, mass balance and nuclear energy",
    "Complete a documented virtual project in each of six engineering disciplines",
    "Design, test and present an original solution to a real-world problem"
  ],
  publishedWeeks: [1],
  units: [
    { title: "Design process and tools", weeks: [1, 2, 3] },
    { title: "Civil engineering", weeks: [4, 5] },
    { title: "Mechanical engineering", weeks: [6, 7] },
    { title: "Electrical engineering", weeks: [8, 9] },
    { title: "Aerospace engineering", weeks: [10, 11] },
    { title: "Chemical engineering", weeks: [12, 13] },
    { title: "Nuclear engineering", weeks: [14, 15] },
    { title: "Final engineering challenge", weeks: [16, 17, 18] }
  ],
  weeks: [
    { title: "The engineering design process", summary: "The disciplines, the design process and how engineers make decisions.",
      lessons: [
        ["Engineering as a profession", "The major disciplines, what they do and how they work together."],
        ["The engineering design process", "The eight steps engineers use to move from problem to solution."],
        ["Defining the problem", "Write a design brief with clear criteria and constraints."],
        ["Decision matrices", "Choose between ideas objectively with a weighted decision matrix."],
        ["Documentation and the engineering notebook", "Record your work so others can trust and repeat it."]
      ] },
    { title: "Technical communication", summary: "Sketches, drawings, dimensions and measurement.",
      lessons: [
        ["Pictorial sketching", "Isometric and oblique sketches of 3D objects."],
        ["Orthographic projection", "Front, top and right views and how they line up."],
        ["Dimensioning and tolerances", "Add dimensions that let someone else build your part."],
        ["Units and conversions", "SI units, unit conversion and significant figures."],
        ["Precision measurement", "Read calipers and rulers and record measurement uncertainty."]
      ] },
    { title: "CAD foundations", summary: "From Tinkercad to parametric modeling in Onshape.",
      lessons: [
        ["Tinkercad power skills", "Workplanes, align, shape generators and exporting STL files."],
        ["Onshape sketches and constraints", "Create fully defined 2D sketches."],
        ["Extrude, revolve and fillet", "Turn sketches into solid parts."],
        ["Assemblies and drawings", "Mate parts together and create a dimensioned drawing."],
        ["Project: model a real part", "Measure a real object and model it with a drawing."]
      ] },
    { title: "Statics and structures", summary: "Forces, equilibrium, trusses and materials.",
      lessons: [
        ["Forces and free-body diagrams", "Represent forces as vectors and draw free-body diagrams."],
        ["Equilibrium and support reactions", "Use sum of forces and moments to find reactions."],
        ["Truss analysis", "Find member forces with the method of joints."],
        ["Stress, strain and factor of safety", "How materials respond to loads and how engineers build in safety."],
        ["Bridge simulator basics", "Build and load-test a truss bridge in a simulator."]
      ] },
    { title: "Civil project: truss bridge", summary: "Design the lowest-cost bridge that passes a load test.",
      lessons: [
        ["Project brief: highway truss bridge", "Criteria, constraints and scoring for the bridge project."],
        ["First design in the simulator", "Build a bridge that passes the load test."],
        ["Optimize cost and strength", "Iterate to lower cost while keeping a safe design."],
        ["Model the bridge in CAD", "Create a 3D model of your final truss."],
        ["Bridge report and presentation", "Document your design decisions and results."]
      ] },
    { title: "Machines and mechanisms", summary: "Mechanical advantage, gears, energy and linkages.",
      lessons: [
        ["Simple machines and mechanical advantage", "Calculate ideal and actual mechanical advantage."],
        ["Gear ratios, torque and speed", "How gear trains trade speed for torque."],
        ["Work, energy, power and efficiency", "Calculate energy flow through a machine."],
        ["Linkages and motion", "Four-bar linkages and the motion they create."],
        ["Mates and motion in Onshape", "Make a CAD assembly that moves."]
      ] },
    { title: "Mechanical project: gearbox", summary: "Design a gearbox that hits a target output speed.",
      lessons: [
        ["Project brief: winch gearbox", "Requirements for a hand-crank or motor-driven winch."],
        ["Gear calculations", "Choose gears to meet the speed and torque target."],
        ["Model gears and housing", "Build the gearbox parts in Onshape."],
        ["Assemble and animate", "Assemble with mates and check the gear motion."],
        ["Gearbox design review", "Present calculations and CAD in a design review."]
      ] },
    { title: "Circuits", summary: "Voltage, current, resistance and microcontrollers.",
      lessons: [
        ["Charge, voltage, current and resistance", "The four core ideas of electricity."],
        ["Ohm's law and power", "Calculate voltage, current, resistance and power."],
        ["Series and parallel circuits", "How components share voltage and current."],
        ["Tinkercad Circuits and the multimeter", "Build and measure circuits on a virtual breadboard."],
        ["Intro to Arduino", "Write your first program to control an LED."]
      ] },
    { title: "Electrical project: smart device", summary: "Build a sensor-driven device in Tinkercad Circuits.",
      lessons: [
        ["Project brief: smart device", "Choose a parking sensor, night light or plant monitor."],
        ["Sensors and inputs", "Read sensors with analog and digital inputs."],
        ["Program the logic", "Use if statements and thresholds to control outputs."],
        ["Test and debug", "Find and fix circuit and code errors."],
        ["Device demo and documentation", "Demo your device with a schematic and code notes."]
      ] },
    { title: "Flight and rocketry", summary: "The physics of flight and rockets, and OpenRocket.",
      lessons: [
        ["Forces of flight", "Lift, weight, thrust and drag on an aircraft."],
        ["The lift equation", "Calculate how speed, area and air density change lift."],
        ["Newton's laws and rockets", "Thrust, impulse and the rocket's flight profile."],
        ["Rocket stability", "Center of gravity, center of pressure and stability margin."],
        ["OpenRocket basics", "Build and simulate your first rocket design."]
      ] },
    { title: "Aerospace project: target altitude rocket", summary: "Design a rocket that reaches a target altitude.",
      lessons: [
        ["Project brief: altitude challenge", "Reach a target altitude with a safe stability margin."],
        ["Design the rocket", "Choose a body, nose cone, fins and motor."],
        ["Simulate and analyze", "Read altitude, velocity and stability data."],
        ["Optimize the design", "Change one variable at a time to hit the target."],
        ["Flight report", "Present your design and simulation data."]
      ] },
    { title: "Chemical engineering fundamentals", summary: "Processes, mass balances and reactions at scale.",
      lessons: [
        ["Meet chemical engineering", "Turning raw materials into useful products at large scale."],
        ["Mass balances", "What goes in must come out: tracking material through a process."],
        ["Reactions and stoichiometry", "Use balanced equations to size a process."],
        ["Separation processes", "Filtration, distillation and other ways to separate mixtures."],
        ["Process flow diagrams", "Read and draw diagrams of chemical processes."]
      ] },
    { title: "Chemical project: water treatment plant", summary: "Design a water treatment process for a small town.",
      lessons: [
        ["Project brief: clean water for a town", "Demand, water quality targets and constraints."],
        ["Research treatment steps", "Coagulation, sedimentation, filtration and disinfection."],
        ["Draw the process flow diagram", "Lay out your plant from intake to tap."],
        ["Mass balance calculations", "Size flows and chemical doses for your plant."],
        ["Plant design presentation", "Present your PFD and calculations."]
      ] },
    { title: "Nuclear engineering fundamentals", summary: "Atoms, fission, radiation and reactors.",
      lessons: [
        ["Atoms and isotopes", "Protons, neutrons and why some nuclei are unstable."],
        ["Fission and fusion", "Where nuclear energy comes from: E = mc²."],
        ["Radiation and safety", "Types of radiation, dose and shielding."],
        ["How a reactor works", "Fuel, moderator, control rods and coolant."],
        ["Fission simulation", "Explore chain reactions in a PhET simulation."]
      ] },
    { title: "Nuclear project: power plant analysis", summary: "Size a power plant and compare it to other energy sources.",
      lessons: [
        ["Project brief: power for a city", "Energy demand and the questions your analysis must answer."],
        ["Energy calculations", "Fuel needed, efficiency and output for a reactor."],
        ["Safety systems", "Defense in depth and lessons from past accidents."],
        ["Compare energy sources", "Cost, emissions, land use and reliability."],
        ["Recommendation report", "Present your recommendation with evidence."]
      ] },
    { title: "Final challenge: define", summary: "Pick a discipline and a real-world problem.",
      lessons: [
        ["Final challenge overview", "Requirements, timeline and grading."],
        ["Choose a discipline and problem", "Find a real problem that fits a discipline you enjoyed."],
        ["Research", "Background, existing solutions and constraints."],
        ["Design specifications", "Write measurable criteria and constraints."],
        ["Brainstorm and select", "Generate concepts and choose with a decision matrix."]
      ] },
    { title: "Final challenge: develop", summary: "Model, simulate, test and improve your design.",
      lessons: [
        ["CAD or simulation, part 1", "Build the core of your design in the right tool."],
        ["CAD or simulation, part 2", "Complete the model and prepare to test."],
        ["Test against specifications", "Collect data on how well your design performs."],
        ["Iterate", "Improve the design based on test results."],
        ["Document the design", "Assemble notebook entries, drawings and data."]
      ] },
    { title: "Final challenge: present", summary: "Present your solution and reflect on the course.",
      lessons: [
        ["Build the presentation", "Structure a technical presentation."],
        ["Rehearse", "Practice, time and refine with feedback."],
        ["Presentations, day 1", "Present and answer technical questions."],
        ["Presentations, day 2", "Present and give peer feedback."],
        ["Course reflection and next steps", "Reflect on the disciplines and plan your path forward."]
      ] }
  ]
});
