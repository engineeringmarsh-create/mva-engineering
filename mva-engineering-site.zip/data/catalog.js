/* ==========================================================================
   Course catalog
   The list of courses on the site. To add a new course:
     1. Create a folder in /data (e.g. /data/robotics)
     2. Add a course.js in that folder (copy /templates/course-template.js)
     3. Add one line below
   `folder` is relative to the site root.
   ========================================================================== */
window.MVA = window.MVA || {};
MVA.catalog = [
  { id: "elements", code: "EE", title: "Elements of Engineering", folder: "data/elements" },
  { id: "basic",    code: "BE", title: "Basic Engineering",       folder: "data/basic" },
  { id: "advanced", code: "AE", title: "Advanced Engineering",    folder: "data/advanced" }
];
