/* ==========================================================================
   Page renderers for course listing, course overview, weekly module and
   progress pages. Each page has a root element with data-page="...".
   ========================================================================== */
(function () {
  "use strict";
  var esc = MVA.esc, pad = MVA.pad;

  MVA.ready(function () {
    var root = document.querySelector("[data-page]");
    if (!root) return;
    var page = root.getAttribute("data-page");
    var fn = { courses: courseSheets, home: courseSheets, course: coursePage, week: weekPage, progress: progressPage }[page];
    if (fn) fn(root);
  });

  function totalLessons(c) { return c.weeks.length * 5; }

  /* ---------- Course sheets (home + courses list) ---------- */
  function courseSheets(root) {
    var host = root.querySelector("[data-sheets]") || root;
    MVA.loadAllCourses().then(function (courses) {
      host.innerHTML = courses.map(function (c) {
        var done = MVA.progress.count(c.id), total = totalLessons(c);
        return '<a class="course-sheet" data-c="' + c.id + '" href="' + MVA.url.course(c.id) + '">' +
          '<div class="cs-top"><span class="cs-code">' + c.code + " · " + esc(c.level) + "</span><h3>" + esc(c.title) + "</h3></div>" +
          '<div class="cs-body"><p>' + esc(c.tagline) + '</p><ul class="tag-list">' +
          c.disciplines.map(function (d) { return "<li>" + esc(d) + "</li>"; }).join("") + "</ul></div>" +
          '<div class="cs-meta"><div><b>Length</b>' + c.weeks.length + " weeks, " + total + " lessons</div>" +
          "<div><b>Your progress</b>" + done + " of " + total + " done</div></div>" +
          '<div class="cs-progress" aria-hidden="true"><span style="width:' + (done / total * 100) + '%"></span></div></a>';
      }).join("");
    });
  }

  /* ---------- Course overview ---------- */
  function coursePage(root) {
    var p = MVA.params();
    document.body.setAttribute("data-course", p.course);
    MVA.loadCourse(p.course).then(function (c) {
      document.title = c.title + " | " + MVA.site.name;
      var done = MVA.progress.count(c.id), total = totalLessons(c);
      var resume = firstUnfinished(c);

      var units = (c.units || []).map(function (u) {
        var weeks = u.weeks.map(function (w) {
          var wk = c.weeks[w - 1];
          var dots = "";
          for (var d = 1; d <= 5; d++) dots += '<span class="' + (MVA.progress.isDone(c.id, w, d) ? "done" : "") + '"></span>';
          return '<a class="week-card" href="' + MVA.url.week(c.id, w) + '"><span class="wk">Week ' + pad(w) + (MVA.isPublished(c, w) ? "" : " · in development") + "</span>" +
            "<h4>" + esc(wk.title) + "</h4><p>" + esc(wk.summary) + '</p><div class="dots" aria-label="' + MVA.progress.weekCount(c.id, w) + ' of 5 lessons complete">' + dots + "</div></a>";
        }).join("");
        return '<section class="unit"><div class="unit-head"><h3>' + esc(u.title) + '</h3><span class="muted">Weeks ' + u.weeks[0] + "–" + u.weeks[u.weeks.length - 1] + "</span></div>" +
          '<div class="week-list">' + weeks + "</div></section>";
      }).join("");

      root.innerHTML =
        '<div class="course-hero"><div class="wrap"><div class="page-head">' +
        '<nav class="crumbs" aria-label="Breadcrumb"><a href="courses.html">Courses</a><span aria-hidden="true">/</span>' + esc(c.title) + "</nav>" +
        "<h1>" + esc(c.title) + '</h1><p class="lede">' + esc(c.description) + "</p>" +
        '<div class="titleblock" style="--tb-cols:4">' +
        '<div><span class="tb-label">Course code</span><span class="tb-value">' + c.code + "</span></div>" +
        '<div><span class="tb-label">Level</span><span class="tb-value">' + esc(c.level) + "</span></div>" +
        '<div><span class="tb-label">Prerequisite</span><span class="tb-value">' + esc(c.audience) + "</span></div>" +
        '<div style="border-right:0"><span class="tb-label">Your progress</span><span class="tb-value">' + done + " of " + total + " lessons</span></div>" +
        '<div class="tb-full" style="grid-column:1/-1;border-bottom:0;border-right:0"><span class="tb-label">Tools</span><span class="tb-value">' + esc(c.tools.join(", ")) + "</span></div>" +
        "</div>" +
        '<div class="btn-row" style="margin-top:24px"><a class="btn btn-signal" href="' + MVA.url.lesson(c.id, resume[0], resume[1]) + '">' +
        (done ? "Continue: Week " + resume[0] + ", Day " + resume[1] : "Start Week 1, Day 1") + "</a></div>" +
        "</div></div></div>" +
        '<div class="wrap"><section class="section"><h2>What you\'ll be able to do</h2><ol class="objectives">' +
        c.outcomes.map(function (o) { return "<li><span>" + esc(o) + "</span></li>"; }).join("") + "</ol></section>" +
        '<section class="section"><h2>Course map</h2><p class="muted">' + c.weeks.length + " weeks · 5 lessons per week · " + total + " lessons</p>" + units + "</section></div>";
    }).catch(function () {
      root.innerHTML = '<div class="wrap"><div class="page-head"><h1>Course not found</h1><p class="lede"><a href="courses.html">See all courses</a></p></div></div>';
    });
  }

  function firstUnfinished(c) {
    for (var w = 1; w <= c.weeks.length; w++)
      for (var d = 1; d <= 5; d++)
        if (!MVA.progress.isDone(c.id, w, d)) return [w, d];
    return [1, 1];
  }

  /* ---------- Weekly module ---------- */
  function weekPage(root) {
    var p = MVA.params();
    document.body.setAttribute("data-course", p.course);
    MVA.loadCourse(p.course).then(function (c) {
      var wk = c.weeks[p.week - 1];
      if (!wk) throw new Error("no week");
      document.title = "Week " + p.week + ": " + wk.title + " | " + c.title;
      var unit = (c.units || []).filter(function (u) { return u.weeks.indexOf(p.week) !== -1; })[0];
      return MVA.loadWeek(c, p.week).then(function (data) {
        var rows = wk.lessons.map(function (l, i) {
          var d = i + 1;
          var ready = data && data[d];
          var done = MVA.progress.isDone(c.id, p.week, d);
          var status = done ? '<span class="status done">Complete</span>' : ready ? '<span class="status ready">Ready</span>' : '<span class="status draft">In development</span>';
          return '<li class="day-row"><div class="day-num">D' + pad(d) + "<small>Day " + d + "</small></div>" +
            '<div><h3><a href="' + MVA.url.lesson(c.id, p.week, d) + '">' + esc(l[0]) + "</a></h3><p>" + esc(l[1]) +
            (ready && ready.duration ? " <span class=\"muted\">(" + esc(ready.duration) + ")</span>" : "") + "</p></div>" + status + "</li>";
        }).join("");
        var prev = p.week > 1 ? '<a class="btn" href="' + MVA.url.week(c.id, p.week - 1) + '">Week ' + (p.week - 1) + "</a>" : "<span></span>";
        var next = p.week < c.weeks.length ? '<a class="btn" href="' + MVA.url.week(c.id, p.week + 1) + '">Week ' + (p.week + 1) + "</a>" : "<span></span>";

        root.innerHTML =
          '<div class="graph"><div class="wrap"><div class="page-head">' +
          '<nav class="crumbs" aria-label="Breadcrumb"><a href="courses.html">Courses</a><span aria-hidden="true">/</span><a href="' + MVA.url.course(c.id) + '">' + esc(c.title) + "</a></nav>" +
          "<h1>Week " + p.week + ": " + esc(wk.title) + '</h1><p class="lede">' + esc(wk.summary) + "</p>" +
          '<div class="titleblock" style="--tb-cols:4;margin-top:24px">' +
          '<div class="tb-wide"><span class="tb-label">Unit</span><span class="tb-value">' + esc(unit ? unit.title : "") + "</span></div>" +
          '<div><span class="tb-label">Week</span><span class="tb-value">' + pad(p.week) + " of " + c.weeks.length + "</span></div>" +
          '<div style="border-right:0"><span class="tb-label">Completed</span><span class="tb-value">' + MVA.progress.weekCount(c.id, p.week) + " of 5</span></div>" +
          "</div></div></div></div>" +
          '<div class="wrap section"><ol class="day-list">' + rows + "</ol>" +
          '<div class="pager">' + prev + '<a class="btn" href="' + MVA.url.course(c.id) + '">Course map</a>' + next + "</div></div>";
      });
    }).catch(function () {
      root.innerHTML = '<div class="wrap"><div class="page-head"><h1>Week not found</h1><p class="lede"><a href="courses.html">See all courses</a></p></div></div>';
    });
  }

  /* ---------- Progress tracker ---------- */
  function progressPage(root) {
    var host = root.querySelector("[data-progress]");
    MVA.loadAllCourses().then(function (courses) {
      host.innerHTML = courses.map(function (c) {
        var done = MVA.progress.count(c.id), total = totalLessons(c);
        var color = { elements: "var(--ee)", basic: "var(--be)", advanced: "var(--ae)" }[c.id] || "var(--ink)";
        var grid = '<div class="wk-label"></div>' + [1, 2, 3, 4, 5].map(function (d) { return '<div class="hd">D' + d + "</div>"; }).join("");
        c.weeks.forEach(function (wk, wi) {
          var w = wi + 1;
          grid += '<div class="wk-label">W' + pad(w) + "</div>";
          for (var d = 1; d <= 5; d++) {
            var isDone = MVA.progress.isDone(c.id, w, d);
            grid += '<a href="' + MVA.url.lesson(c.id, w, d) + '" class="' + (isDone ? "done" : "") + '" title="Week ' + w + ", Day " + d + ": " + esc(wk.lessons[d - 1][0]) + (isDone ? " (complete)" : "") + '"><span class="sr-only" style="position:absolute;left:-9999px">' +
              "Week " + w + " Day " + d + (isDone ? " complete" : "") + "</span></a>";
          }
        });
        return '<section class="prog-course" style="--c:' + color + '"><div class="prog-head"><h3><a href="' + MVA.url.course(c.id) + '" style="color:inherit">' + esc(c.title) + "</a></h3>" +
          '<span class="muted">' + done + " of " + total + " lessons (" + Math.round(done / total * 100) + "%)</span></div>" +
          '<div class="bar"><span style="width:' + (done / total * 100) + '%"></span></div>' +
          '<div class="prog-grid">' + grid + "</div>" +
          '<p style="margin-top:12px"><button class="btn small" type="button" data-reset="' + c.id + '">Reset ' + esc(c.title) + " progress</button></p></section>";
      }).join("");

      host.onclick = function (e) {
        var b = e.target.closest("[data-reset]");
        if (!b) return;
        if (confirm("Clear your saved progress for this course on this device? Your Canvas submissions are not affected.")) {
          MVA.progress.reset(b.getAttribute("data-reset"));
          progressPage(root);
        }
      };
    });
  }
})();
