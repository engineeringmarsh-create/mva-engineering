/* ==========================================================================
   Lesson renderer — powers lesson.html
   URL: lesson.html?course=basic&week=4&day=3

   Every lesson renders in the same seven sections:
     1 Learning objectives   2 Reading and instruction   3 Guided walkthrough
     4 Worked example        5 Activity or project work  6 Reflection questions
     7 Completion screen

   The completion screen unlocks once a student has opened sections 1–6 and
   answered every reflection question. It shows a verification code such as
   BE-W04-D03-5837 whose last four digits are random and change on every load.
   ========================================================================== */
(function () {
  "use strict";
  var esc = MVA.esc, pad = MVA.pad;

  var SECTIONS = [
    { id: "objectives", label: "Learning objectives" },
    { id: "reading", label: "Reading and instruction" },
    { id: "walkthrough", label: "Guided walkthrough" },
    { id: "example", label: "Worked example" },
    { id: "activity", label: "Activity" },
    { id: "reflection", label: "Reflection" },
    { id: "complete", label: "Completion" }
  ];

  var state = { current: 0, seen: {}, code: null, generatedAt: null };

  MVA.ready(init);

  function init() {
    var p = MVA.params();
    var main = document.getElementById("lesson-root");
    if (!p.course || !p.week || !p.day) return notFound(main, "This link is missing the course, week or day.");
    document.body.setAttribute("data-course", p.course);

    MVA.loadCourse(p.course).then(function (course) {
      var wk = course.weeks[p.week - 1];
      if (!wk || !wk.lessons[p.day - 1]) return notFound(main, "There is no Week " + p.week + ", Day " + p.day + " in " + course.title + ".");
      return MVA.loadWeek(course, p.week).then(function (weekData) {
        var content = weekData ? weekData[p.day] : null;
        render(main, course, p.week, p.day, wk, content);
      });
    }).catch(function () {
      notFound(main, "We couldn't find that course.");
    });
  }

  function notFound(main, msg) {
    main.innerHTML =
      '<div class="wrap"><div class="page-head"><h1>Lesson not found</h1><p class="lede">' + esc(msg) +
      '</p></div><p style="margin-top:24px"><a class="btn" href="courses.html">Go to all courses</a></p></div>';
  }

  function neighbors(course, w, d) {
    var total = course.weeks.length;
    var prev = d > 1 ? [w, d - 1] : (w > 1 ? [w - 1, 5] : null);
    var next = d < 5 ? [w, d + 1] : (w < total ? [w + 1, 1] : null);
    return { prev: prev, next: next };
  }

  function header(course, w, d, wk) {
    var title = wk.lessons[d - 1][0];
    document.title = title + " | " + course.title + " | " + MVA.site.name;
    var unit = (course.units || []).filter(function (u) { return u.weeks.indexOf(w) !== -1; })[0];
    return (
      '<div class="graph"><div class="wrap"><div class="page-head">' +
      '<nav class="crumbs" aria-label="Breadcrumb"><a href="courses.html">Courses</a><span aria-hidden="true">/</span>' +
      '<a href="' + MVA.url.course(course.id) + '">' + esc(course.title) + '</a><span aria-hidden="true">/</span>' +
      '<a href="' + MVA.url.week(course.id, w) + '">Week ' + w + "</a></nav>" +
      '<div class="titleblock" style="--tb-cols:6">' +
      '<div class="tb-title tb-full" style="grid-column:1/-1"><span class="tb-label">Lesson</span><span class="tb-value"><h1 style="font-size:inherit;margin:0">' + esc(title) + "</h1></span></div>" +
      '<div class="tb-wide"><span class="tb-label">Course</span><span class="tb-value">' + esc(course.title) + "</span></div>" +
      '<div class="tb-wide"><span class="tb-label">Unit</span><span class="tb-value">' + esc(unit ? unit.title : "") + "</span></div>" +
      '<div><span class="tb-label">Week</span><span class="tb-value">' + pad(w) + " of " + course.weeks.length + "</span></div>" +
      '<div style="border-right:0"><span class="tb-label">Day</span><span class="tb-value">' + pad(d) + " of 05</span></div>" +
      '<div class="tb-full" style="grid-column:1/-1;border-bottom:0;border-right:0"><span class="tb-label">Focus</span><span class="tb-value" style="font-weight:500">' + esc(wk.lessons[d - 1][1]) + "</span></div>" +
      "</div></div></div></div>"
    );
  }

  function lessonPager(course, w, d) {
    var n = neighbors(course, w, d);
    var prev = n.prev ? '<a class="btn" href="' + MVA.url.lesson(course.id, n.prev[0], n.prev[1]) + '">Previous lesson: W' + n.prev[0] + " D" + n.prev[1] + "</a>" : "<span></span>";
    var next = n.next ? '<a class="btn" href="' + MVA.url.lesson(course.id, n.next[0], n.next[1]) + '">Next lesson: W' + n.next[0] + " D" + n.next[1] + "</a>" : "<span></span>";
    return '<div class="pager">' + prev + '<a class="btn" href="' + MVA.url.week(course.id, w) + '">Week ' + w + " overview</a>" + next + "</div>";
  }

  /* ---------- Draft lesson (not written yet) ---------- */
  function renderDraft(main, course, w, d, wk) {
    main.innerHTML = header(course, w, d, wk) +
      '<div class="wrap"><div class="draft-banner"><h2 style="font-size:1.6rem">This lesson isn\'t published yet</h2>' +
      "<p>Mr. Marsh is still writing this lesson. Here's what it will cover:</p>" +
      '<p><b>' + esc(wk.lessons[d - 1][0]) + ":</b> " + esc(wk.lessons[d - 1][1]) + "</p>" +
      '<p class="muted">This week: ' + esc(wk.summary) + "</p>" +
      "<p>If your teacher assigned this lesson, check Canvas for instructions. There is no completion code for unpublished lessons.</p></div>" +
      lessonPager(course, w, d) + "</div>";
  }

  /* ---------- Full lesson ---------- */
  function render(main, course, w, d, wk, L) {
    if (!L) return renderDraft(main, course, w, d, wk);

    state.code = MVA.makeCode(course.code, w, d);
    state.generatedAt = new Date();
    var rkey = "mva-reflect-" + course.id + "-W" + pad(w) + "-D" + pad(d);
    var tkey = "mva-tasks-" + course.id + "-W" + pad(w) + "-D" + pad(d);
    state.rkey = rkey; state.tkey = tkey;
    state.reflection = L.reflection || [];

    var steps = SECTIONS.map(function (s, i) {
      return '<li><button type="button" data-step="' + i + '"><span>' + s.label + "</span></button></li>";
    }).join("");

    main.innerHTML = header(course, w, d, wk) +
      '<div class="wrap"><div class="lesson-layout">' +
      '<aside class="lesson-steps" aria-label="Lesson sections"><ol>' + steps + "</ol>" +
      '<div class="meter" aria-hidden="true"><span></span></div>' +
      '<p class="small muted" id="meter-text"></p>' +
      (L.duration ? '<p class="small muted">Estimated time: ' + esc(L.duration) + "</p>" : "") +
      "</aside>" +
      '<div class="lesson-body">' +
      panel(0, objectivesHTML(L)) +
      panel(1, readingHTML(L)) +
      panel(2, walkthroughHTML(L)) +
      panel(3, exampleHTML(L)) +
      panel(4, activityHTML(L)) +
      panel(5, reflectionHTML(L)) +
      panel(6, '<div id="completion-slot"></div>') +
      "</div></div>" + lessonPager(course, w, d) + "</div>";

    wire(main, course, w, d, wk, L);
    var start = 0;
    var hash = location.hash.replace("#", "");
    SECTIONS.forEach(function (s, i) { if (s.id === hash && i < 6) start = i; });
    go(start, false);
  }

  function panel(i, inner) {
    var s = SECTIONS[i];
    var nav = '<div class="panel-nav">' +
      (i > 0 ? '<button class="btn" type="button" data-go="' + (i - 1) + '">Back: ' + SECTIONS[i - 1].label + "</button>" : "<span></span>") +
      (i < SECTIONS.length - 1 ? '<button class="btn btn-primary" type="button" data-go="' + (i + 1) + '">Next: ' + SECTIONS[i + 1].label + "</button>" : "") +
      "</div>";
    return '<section class="lesson-panel" id="panel-' + s.id + '" data-panel="' + i + '" hidden tabindex="-1" aria-labelledby="h-' + s.id + '">' +
      '<div class="panel-head"><h2 id="h-' + s.id + '">' + s.label + '</h2><span class="muted">Section ' + (i + 1) + " of 7</span></div>" +
      inner + nav + "</section>";
  }

  function objectivesHTML(L) {
    var list = (L.objectives || []).map(function (o) { return "<li><span>" + o + "</span></li>"; }).join("");
    return '<p class="prose">By the end of this lesson you will be able to:</p><ol class="objectives">' + list + "</ol>" +
      (L.before ? '<div class="callout signal"><h4>Before you start</h4>' + L.before + "</div>" : "") +
      '<div class="callout"><h4>How to complete this lesson</h4><p>Work through all seven sections in order. Answer every reflection question. ' +
      "Your completion code appears on the last screen. Copy it into the Canvas assignment for this lesson.</p></div>";
  }

  function readingHTML(L) {
    var html = '<div class="prose">' + (L.reading || "") + "</div>";
    if (L.vocab && L.vocab.length) {
      html += '<h3>Key vocabulary</h3><dl class="vocab">' + L.vocab.map(function (v) {
        return "<div><dt>" + esc(v[0]) + "</dt><dd>" + v[1] + "</dd></div>";
      }).join("") + "</dl>";
    }
    if (L.check && L.check.length) html += checkpointHTML(L.check);
    return html;
  }

  function checkpointHTML(qs) {
    return '<div class="checkpoint"><h4>Quick check</h4><p class="small muted">Not graded. Pick an answer to see if you\'re on track.</p>' +
      qs.map(function (q, qi) {
        return '<fieldset data-q="' + qi + '" data-answer="' + q.answer + '"><legend>' + (qi + 1) + ". " + q.q + "</legend>" +
          q.options.map(function (o, oi) {
            return '<label><input type="radio" name="cq' + qi + '" value="' + oi + '"><span>' + o + "</span></label>";
          }).join("") +
          '<p class="fb" hidden data-explain="' + esc(q.explain || "") + '"></p></fieldset>';
      }).join("") + "</div>";
  }

  function walkthroughHTML(L) {
    var W = L.walkthrough || {};
    var steps = (W.steps || []).map(function (s, i) {
      return '<li><details class="walk-step"' + (i === 0 ? " open" : "") + '><summary><span class="n">Step ' + (i + 1) + "</span><span>" + s.title +
        '</span></summary><div class="body prose">' + s.body + "</div></details></li>";
    }).join("");
    return (W.intro ? '<div class="prose">' + W.intro + "</div>" : "") +
      '<ol class="walk-steps">' + steps + "</ol>" +
      (W.steps && W.steps.length > 1 ? '<p class="small muted">Open each step in order. Try the step yourself before moving to the next one.</p>' : "");
  }

  function exampleHTML(L) {
    var E = L.example;
    if (!E) return "";
    return (E.intro ? '<div class="prose">' + E.intro + "</div>" : "") +
      '<div class="example"><div class="ex-q"><b>' + (E.title || "Problem") + "</b>" + E.problem + "</div>" +
      '<p class="small muted" style="margin:12px 18px 0">Try it on your own first, then reveal the solution.</p>' +
      '<div data-solution hidden><ol>' + E.steps.map(function (s) { return "<li>" + s + "</li>"; }).join("") + "</ol>" +
      '<div class="ex-a">' + E.answer + "</div></div>" +
      '<button type="button" class="btn reveal-btn" data-reveal>Show the solution</button></div>' +
      (E.takeaway ? '<div class="callout"><h4>Takeaway</h4><p>' + E.takeaway + "</p></div>" : "");
  }

  function activityHTML(L) {
    var A = L.activity || {};
    var saved = MVA.store.get(state.tkey, {});
    var meta = '<div class="titleblock activity-meta">' +
      '<div class="tb-full" style="grid-column:1/-1;border-right:0"><span class="tb-label">Activity</span><span class="tb-value" style="font-family:var(--font-display);font-size:1.5rem">' + esc(A.title || "") + "</span></div>" +
      '<div><span class="tb-label">Time</span><span class="tb-value">' + esc(A.time || "") + "</span></div>" +
      '<div><span class="tb-label">Tools</span><span class="tb-value">' + esc((A.tools || []).join(", ")) + "</span></div>" +
      '<div style="border-right:0"><span class="tb-label">Turn in</span><span class="tb-value">' + esc(A.deliverable || "") + "</span></div>" +
      "</div>";
    var tasks = (A.steps || []).map(function (s, i) {
      var id = "task-" + i;
      return '<li><input type="checkbox" id="' + id + '" data-task="' + i + '"' + (saved[i] ? " checked" : "") + '><label for="' + id + '">' + s + "</label></li>";
    }).join("");
    return meta + (A.intro ? '<div class="prose">' + A.intro + "</div>" : "") +
      "<h3>Steps</h3><p class=\"small muted\">Check off each step as you finish it. Your checks are saved on this device.</p>" +
      '<ul class="task-list">' + tasks + "</ul>" +
      (A.rubric ? '<h3>How it\'s graded</h3><div class="prose">' + A.rubric + "</div>" : "") +
      (A.extension ? '<div class="callout signal"><h4>Finished early?</h4><p>' + A.extension + "</p></div>" : "") +
      (L.resources && L.resources.length ? "<h3>Resources</h3><ul class=\"prose\">" + L.resources.map(function (r) {
        return '<li><a href="' + esc(r.url) + '" target="_blank" rel="noopener">' + esc(r.label) + "</a></li>";
      }).join("") + "</ul>" : "");
  }

  function reflectionHTML(L) {
    var saved = MVA.store.get(state.rkey, {});
    return '<div class="reflect"><p>Answer each question in complete sentences. Your answers are saved on this device as you type. ' +
      "You need to answer every question to unlock your completion code.</p>" +
      (L.reflection || []).map(function (q, i) {
        return '<label for="r' + i + '">' + (i + 1) + ". " + q + "</label>" +
          '<textarea id="r' + i + '" data-r="' + i + '">' + esc(saved[i] || "") + "</textarea>";
      }).join("") +
      '<p class="save-note" id="save-note" aria-live="polite"></p></div>';
  }

  /* ---------- Completion ---------- */
  var MIN_CHARS = 15;

  function reflectionsDone() {
    var saved = MVA.store.get(state.rkey, {});
    var areas = document.querySelectorAll("[data-r]");
    for (var i = 0; i < state.reflection.length; i++) {
      var v = areas[i] ? areas[i].value : (saved[i] || "");
      if ((v || "").trim().length < MIN_CHARS) return false;
    }
    return true;
  }

  function sectionsDone() {
    for (var i = 0; i < 6; i++) if (!state.seen[i]) return false;
    return true;
  }

  function renderCompletion(course, w, d, wk) {
    var slot = document.getElementById("completion-slot");
    var okSections = sectionsDone(), okReflect = reflectionsDone();
    if (!okSections || !okReflect) {
      var missing = [];
      for (var i = 0; i < 6; i++) if (!state.seen[i]) missing.push('<li><button class="btn" type="button" data-go="' + i + '">Open ' + SECTIONS[i].label + "</button></li>");
      slot.innerHTML = '<div class="locked"><h3>Almost there</h3><p>Your completion code unlocks when you have:</p><ul>' +
        "<li>" + (okSections ? "✓ " : "") + "Opened all six lesson sections</li>" +
        "<li>" + (okReflect ? "✓ " : "") + "Answered every reflection question (at least a full sentence each)</li></ul>" +
        (missing.length ? '<p>Sections you still need to open:</p><ul style="list-style:none;padding:0;display:flex;flex-wrap:wrap;gap:8px">' + missing.join("") + "</ul>" : "") +
        (!okReflect ? '<p><button class="btn btn-primary" type="button" data-go="5">Go to reflection questions</button></p>' : "") +
        "</div>";
      return;
    }

    MVA.progress.mark(course.id, w, d);
    var t = state.generatedAt;
    var when = t.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) + ", " +
      t.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
    var n = neighbors(course, w, d);

    slot.innerHTML =
      '<div class="completion">' +
      '<p class="prose">Nice work. You finished <b>' + esc(wk.lessons[d - 1][0]) + "</b>. Submit your code in Canvas to get credit.</p>" +
      '<div class="stamp" style="margin-top:32px"><span class="approved" aria-hidden="true">COMPLETE</span>' +
      '<div class="stamp-code"><span class="label">Your verification code</span>' +
      '<span class="code" id="vcode">' + state.code + "</span>" +
      '<span class="small muted">This code is new every time the lesson opens. A screenshot from another day won\'t match.</span></div>' +
      '<div class="titleblock" style="--tb-cols:4">' +
      '<div><span class="tb-label">Course</span><span class="tb-value">' + course.code + "</span></div>" +
      '<div><span class="tb-label">Week</span><span class="tb-value">' + pad(w) + "</span></div>" +
      '<div><span class="tb-label">Day</span><span class="tb-value">' + pad(d) + "</span></div>" +
      '<div><span class="tb-label">Generated</span><span class="tb-value">' + esc(when) + "</span></div>" +
      "</div></div>" +
      '<div class="btn-row" style="margin:20px 0 28px"><button class="btn btn-primary" type="button" id="copy-code">Copy code</button>' +
      '<button class="btn" type="button" id="copy-reflect">Copy my reflection answers</button>' +
      '<button class="btn" type="button" onclick="window.print()">Print lesson</button></div>' +
      "<h3>Submit in Canvas</h3><ol>" +
      "<li>Open the Canvas assignment for <b>" + course.code + " Week " + w + " Day " + d + "</b>.</li>" +
      "<li>Paste your verification code: <span class=\"mono\">" + state.code + "</span></li>" +
      "<li>If the assignment asks for reflections, paste your reflection answers too.</li>" +
      "<li>Turn in anything listed under <b>Turn in</b> in the Activity section.</li></ol>" +
      '<div class="btn-row" style="margin-top:24px">' +
      (n.next ? '<a class="btn btn-signal" href="' + MVA.url.lesson(course.id, n.next[0], n.next[1]) + '">Start next lesson: ' + esc(course.weeks[n.next[0] - 1].lessons[n.next[1] - 1][0]) + "</a>" : "") +
      '<a class="btn" href="progress.html">See my progress</a></div></div>';

    document.getElementById("copy-code").addEventListener("click", function () { MVA.copy(state.code, "Code copied"); });
    document.getElementById("copy-reflect").addEventListener("click", function () {
      var areas = document.querySelectorAll("[data-r]");
      var text = course.code + " W" + pad(w) + " D" + pad(d) + ": " + wk.lessons[d - 1][0] + "\nCode: " + state.code + "\n\n" +
        state.reflection.map(function (q, i) { return (i + 1) + ". " + stripTags(q) + "\n" + (areas[i] ? areas[i].value.trim() : ""); }).join("\n\n");
      MVA.copy(text, "Reflection answers copied");
    });
  }

  function stripTags(s) { var div = document.createElement("div"); div.innerHTML = s; return div.textContent; }

  /* ---------- Navigation between sections ---------- */
  var ctx = {};
  function go(i, focus) {
    state.current = i;
    if (i < 6) state.seen[i] = true;
    document.querySelectorAll("[data-panel]").forEach(function (p) { p.hidden = Number(p.getAttribute("data-panel")) !== i; });
    document.querySelectorAll("[data-step]").forEach(function (b) {
      var n = Number(b.getAttribute("data-step"));
      if (n === i) b.setAttribute("aria-current", "step"); else b.removeAttribute("aria-current");
      b.classList.toggle("seen", !!state.seen[n] || (n === 6 && sectionsDone() && reflectionsDone()));
    });
    var seenCount = Object.keys(state.seen).length;
    document.querySelector(".meter span").style.width = Math.round((seenCount / 6) * 100) + "%";
    document.getElementById("meter-text").textContent = seenCount + " of 6 sections opened";
    if (i === 6) renderCompletion(ctx.course, ctx.w, ctx.d, ctx.wk);
    if (history.replaceState) history.replaceState(null, "", "#" + SECTIONS[i].id);
    if (focus !== false) {
      var p = document.getElementById("panel-" + SECTIONS[i].id);
      var layout = document.querySelector(".lesson-layout");
      var top = layout.getBoundingClientRect().top + window.scrollY - 76;
      if (window.scrollY > top) window.scrollTo(0, top);
      p.focus({ preventScroll: true });
    }
  }

  function wire(main, course, w, d, wk) {
    ctx = { course: course, w: w, d: d, wk: wk };

    main.addEventListener("click", function (e) {
      var g = e.target.closest("[data-go]");
      if (g) { go(Number(g.getAttribute("data-go"))); return; }
      var s = e.target.closest("[data-step]");
      if (s) { go(Number(s.getAttribute("data-step"))); return; }
      var r = e.target.closest("[data-reveal]");
      if (r) {
        var sol = r.parentElement.querySelector("[data-solution]");
        sol.hidden = !sol.hidden;
        r.textContent = sol.hidden ? "Show the solution" : "Hide the solution";
      }
    });

    main.addEventListener("change", function (e) {
      var t = e.target;
      if (t.matches(".checkpoint input[type=radio]")) {
        var fs = t.closest("fieldset");
        var right = Number(fs.getAttribute("data-answer")) === Number(t.value);
        var fb = fs.querySelector(".fb");
        fb.hidden = false;
        fb.className = "fb " + (right ? "right" : "wrong");
        fb.textContent = (right ? "Correct. " : "Not quite. ") + fb.getAttribute("data-explain");
      }
      if (t.matches("[data-task]")) {
        var saved = MVA.store.get(state.tkey, {});
        saved[t.getAttribute("data-task")] = t.checked;
        MVA.store.set(state.tkey, saved);
      }
    });

    var timer;
    main.addEventListener("input", function (e) {
      if (!e.target.matches("[data-r]")) return;
      clearTimeout(timer);
      var note = document.getElementById("save-note");
      timer = setTimeout(function () {
        var saved = {};
        document.querySelectorAll("[data-r]").forEach(function (a) { saved[a.getAttribute("data-r")] = a.value; });
        MVA.store.set(state.rkey, saved);
        note.textContent = "Saved on this device.";
      }, 400);
    });
  }
})();
