/* ==========================================================================
   Engineering with Mr. Marsh — shared site script
   Loaded on every page. Provides:
     - MVA.registerCourse / MVA.registerWeek   (used by files in /data)
     - MVA.loadCourse / MVA.loadWeek            (lazy-load curriculum data)
     - MVA.progress                             (localStorage completion tracker)
     - MVA.makeCode                             (lesson verification codes)
     - Shared header + footer
   ========================================================================== */
(function () {
  "use strict";

  var MVA = (window.MVA = window.MVA || {});
  MVA.courses = MVA.courses || {};
  MVA.weeks = MVA.weeks || {};          // MVA.weeks[courseId][weekNumber] = { dayNumber: lesson }
  MVA.site = {
    name: "Engineering with Mr. Marsh",
    school: "Montverde Academy",
    teacher: "Mr. Marsh",
    email: ""               // Set to your school email to enable the contact form
  };

  /* ---------- Helpers ---------- */
  MVA.pad = function (n) { return String(n).padStart(2, "0"); };

  MVA.esc = function (s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  };

  MVA.params = function () {
    var p = new URLSearchParams(location.search);
    return {
      course: (p.get("course") || "").toLowerCase(),
      week: parseInt(p.get("week"), 10) || 0,
      day: parseInt(p.get("day"), 10) || 0
    };
  };

  MVA.url = {
    course: function (c) { return "course.html?course=" + c; },
    week: function (c, w) { return "week.html?course=" + c + "&week=" + w; },
    lesson: function (c, w, d) { return "lesson.html?course=" + c + "&week=" + w + "&day=" + d; }
  };

  MVA.toast = function (msg) {
    var t = document.querySelector(".toast");
    if (!t) { t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); document.body.appendChild(t); }
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(t._h);
    t._h = setTimeout(function () { t.classList.remove("show"); }, 2200);
  };

  MVA.copy = function (text, okMsg) {
    var done = function () { MVA.toast(okMsg || "Copied"); };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, fallback);
    } else { fallback(); }
    function fallback() {
      var ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); done(); } catch (e) { MVA.toast("Select the text and copy it manually"); }
      ta.remove();
    }
  };

  /* ---------- Safe storage (works even when storage is blocked) ---------- */
  var mem = {};
  MVA.store = {
    get: function (k, fallback) {
      try { var v = localStorage.getItem(k); return v == null ? fallback : JSON.parse(v); }
      catch (e) { return k in mem ? mem[k] : fallback; }
    },
    set: function (k, v) {
      try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { mem[k] = v; }
    }
  };

  /* ---------- Data registration (called from /data files) ---------- */
  MVA.registerCourse = function (course) {
    MVA.courses[course.id] = course;
  };

  MVA.registerWeek = function (courseId, week, lessons) {
    MVA.weeks[courseId] = MVA.weeks[courseId] || {};
    MVA.weeks[courseId][week] = lessons;
  };

  /* ---------- Script loader ---------- */
  var loaded = {};
  MVA.loadScript = function (src) {
    if (loaded[src]) return loaded[src];
    loaded[src] = new Promise(function (resolve, reject) {
      var s = document.createElement("script");
      s.src = src;
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error("Could not load " + src)); };
      document.head.appendChild(s);
    });
    return loaded[src];
  };

  MVA.loadCourse = function (id) {
    var entry = (MVA.catalog || []).filter(function (c) { return c.id === id; })[0];
    if (!entry) return Promise.reject(new Error("Unknown course: " + id));
    return MVA.loadScript(entry.folder + "/course.js").then(function () {
      var course = MVA.courses[id];
      course.folder = entry.folder;
      return course;
    });
  };

  MVA.isPublished = function (course, week) {
    return (course.publishedWeeks || []).indexOf(week) !== -1;
  };

  /* Resolves to the week's lesson content object, or null if not yet written. */
  MVA.loadWeek = function (course, week) {
    if (!MVA.isPublished(course, week)) return Promise.resolve(null);
    var src = course.folder + "/week-" + MVA.pad(week) + ".js";
    return MVA.loadScript(src).then(function () {
      return (MVA.weeks[course.id] || {})[week] || null;
    }, function () { return null; });
  };

  MVA.loadAllCourses = function () {
    return Promise.all((MVA.catalog || []).map(function (c) { return MVA.loadCourse(c.id); }));
  };

  /* ---------- Progress tracking ---------- */
  var PKEY = "mva-progress-v1";
  MVA.progress = {
    key: function (w, d) { return "W" + MVA.pad(w) + "-D" + MVA.pad(d); },
    all: function () { return MVA.store.get(PKEY, {}); },
    course: function (c) { return MVA.progress.all()[c] || {}; },
    isDone: function (c, w, d) { return !!MVA.progress.course(c)[MVA.progress.key(w, d)]; },
    mark: function (c, w, d) {
      var all = MVA.progress.all();
      all[c] = all[c] || {};
      all[c][MVA.progress.key(w, d)] = new Date().toISOString();
      MVA.store.set(PKEY, all);
    },
    unmark: function (c, w, d) {
      var all = MVA.progress.all();
      if (all[c]) { delete all[c][MVA.progress.key(w, d)]; MVA.store.set(PKEY, all); }
    },
    count: function (c) { return Object.keys(MVA.progress.course(c)).length; },
    weekCount: function (c, w) {
      var n = 0; for (var d = 1; d <= 5; d++) if (MVA.progress.isDone(c, w, d)) n++; return n;
    },
    reset: function (c) {
      var all = MVA.progress.all();
      if (c) delete all[c]; else all = {};
      MVA.store.set(PKEY, all);
    }
  };

  /* ---------- Verification code ----------
     Format: <COURSE>-W<week>-D<day>-<4 random digits>, e.g. BE-W04-D03-5837
     A new code is generated every time a lesson page loads. */
  MVA.randomDigits = function (n) {
    var out = "";
    var buf = new Uint32Array(n);
    if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(buf);
    else for (var i = 0; i < n; i++) buf[i] = Math.floor(Math.random() * 1e9);
    for (var j = 0; j < n; j++) out += String(buf[j] % 10);
    return out;
  };
  MVA.makeCode = function (courseCode, w, d) {
    return courseCode + "-W" + MVA.pad(w) + "-D" + MVA.pad(d) + "-" + MVA.randomDigits(4);
  };

  /* ---------- Header / footer ---------- */
  var NAV = [
    ["index.html", "Home"],
    ["courses.html", "Courses"],
    ["resources.html", "Resources"],
    ["gallery.html", "Projects"],
    ["progress.html", "My progress"],
    ["pathway.html", "Pathway"],
    ["about.html", "About"],
    ["contact.html", "Contact"]
  ];

  var MARK =
    '<svg class="brand-mark" viewBox="0 0 32 32" aria-hidden="true">' +
    '<rect x="1.5" y="1.5" width="29" height="29" fill="none" stroke="#f2b705" stroke-width="2"/>' +
    '<path d="M7 24 L16 8 L25 24 Z" fill="none" stroke="#fff" stroke-width="2"/>' +
    '<path d="M11.5 16 H20.5" stroke="#fff" stroke-width="2"/>' +
    '<circle cx="16" cy="8" r="2" fill="#f2b705"/></svg>';

  function currentPage() {
    var p = location.pathname.split("/").pop() || "index.html";
    if (["course.html", "week.html", "lesson.html"].indexOf(p) !== -1) return "courses.html";
    return p;
  }

  function renderHeader() {
    var host = document.getElementById("site-header");
    if (!host) return;
    var here = currentPage();
    var items = NAV.map(function (n) {
      return '<li><a href="' + n[0] + '"' + (n[0] === here ? ' aria-current="page"' : "") + ">" + n[1] + "</a></li>";
    }).join("");
    host.outerHTML =
      '<a class="skip-link" href="#main">Skip to content</a>' +
      '<header class="site-header"><div class="wrap">' +
      '<a class="brand" href="index.html">' + MARK + "<span>" + MVA.site.name + "</span></a>" +
      '<button class="nav-toggle" aria-expanded="false" aria-controls="site-nav">Menu</button>' +
      '<nav class="site-nav" id="site-nav" aria-label="Main"><ul>' + items + "</ul></nav>" +
      "</div></header>";
    var btn = document.querySelector(".nav-toggle");
    var nav = document.getElementById("site-nav");
    btn.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  function renderFooter() {
    var host = document.getElementById("site-footer");
    if (!host) return;
    var courses = (MVA.catalog || []).map(function (c) {
      return '<li><a href="' + MVA.url.course(c.id) + '">' + c.title + "</a></li>";
    }).join("");
    host.outerHTML =
      '<footer class="site-footer"><div class="wrap">' +
      "<div><h4>" + MVA.site.name + "</h4><p>Self-paced engineering courses for " + MVA.site.teacher +
      "'s classes at " + MVA.site.school + ". Every lesson is written so you can learn it on your own, even on a day you miss class.</p></div>" +
      "<div><h4>Courses</h4><ul>" + courses + "</ul></div>" +
      '<div><h4>Help</h4><ul><li><a href="resources.html">Resource library</a></li>' +
      '<li><a href="progress.html">My progress</a></li><li><a href="contact.html">Contact Mr. Marsh</a></li></ul></div>' +
      "</div></footer>";
  }

  MVA.ready = function (fn) {
    if (document.readyState !== "loading") fn();
    else document.addEventListener("DOMContentLoaded", fn);
  };

  MVA.ready(function () {
    renderHeader();
    renderFooter();
  });
})();
